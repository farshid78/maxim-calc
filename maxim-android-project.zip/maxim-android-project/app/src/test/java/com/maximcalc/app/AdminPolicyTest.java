package com.maximcalc.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AdminPolicyTest {
    @Test
    public void onlyExactAdminEmailIsAllowed() {
        assertTrue(AdminPolicy.isAdminEmail("farshid.nabipour78@gmail.com"));
        assertTrue(AdminPolicy.isAdminEmail("  FARSHID.Nabipour78@Gmail.com "));
        assertFalse(AdminPolicy.isAdminEmail("farshid.nabipour78@gmail.com.evil.com"));
        assertFalse(AdminPolicy.isAdminEmail("farshid.nabipour78+x@gmail.com"));
        assertFalse(AdminPolicy.isAdminEmail("someone@gmail.com"));
        assertFalse(AdminPolicy.isAdminEmail(""));
        assertFalse(AdminPolicy.isAdminEmail(null));
    }

    @Test
    public void formatValidation() {
        assertTrue(AdminPolicy.validFormat("a@b.co"));
        assertFalse(AdminPolicy.validFormat("abc"));
        assertFalse(AdminPolicy.validFormat("a b@c.com"));
        assertFalse(AdminPolicy.validFormat(null));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 300; i++) {
            sb.append('a');
        }
        assertFalse(AdminPolicy.validFormat(sb + "@x.com"));
    }

    @Test
    public void maskHidesMostOfTheAddress() {
        assertEquals("f***@gmail.com", AdminPolicy.mask("farshid.nabipour78@gmail.com"));
        assertEquals("", AdminPolicy.mask("nonsense"));
    }

    @Test
    public void rateLimitMinGapAndWindow() {
        long now = 10_000_000L;
        assertEquals("", AdminPolicy.checkRate(new long[0], now));
        assertFalse(AdminPolicy.checkRate(new long[]{now - 30_000L}, now).isEmpty());
        assertEquals("", AdminPolicy.checkRate(new long[]{now - 61_000L}, now));
        long[] five = new long[5];
        for (int i = 0; i < 5; i++) {
            five[i] = now - 120_000L - i * 1000L;
        }
        assertFalse(AdminPolicy.checkRate(five, now).isEmpty());
        long[] old = {now - 4_000_000L, now - 4_100_000L, now - 4_200_000L, now - 4_300_000L, now - 4_400_000L};
        assertEquals("", AdminPolicy.checkRate(old, now));
    }

    @Test
    public void recordKeepsOnlyRecentAndParsesBack() {
        long now = 50_000_000L;
        String s = AdminPolicy.record("1,2," + (now - 1000L), now);
        long[] p = AdminPolicy.parse(s);
        assertEquals(2, p.length);
        assertEquals(now, p[1]);
        assertEquals(0, AdminPolicy.parse("garbage,,x").length);
    }
}
