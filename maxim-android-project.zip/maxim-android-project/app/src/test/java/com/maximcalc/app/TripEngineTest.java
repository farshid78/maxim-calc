package com.maximcalc.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TripEngineTest {
    private static TripEngine.Params base() {
        TripEngine.Params p = new TripEngine.Params();
        p.fare = 5586000;
        p.dist = 575.6;
        p.pick = 6.8;
        return p;
    }

    private static TripEngine.Params simple(double fare, double dist) {
        TripEngine.Params p = new TripEngine.Params();
        p.fare = fare;
        p.dist = dist;
        return p;
    }

    @Test
    public void profitableTrip() {
        TripEngine.Result r = TripEngine.compute(base());
        assertTrue(r.valid);
        assertEquals(1158.0, r.totalKm, 1e-6);
        assertEquals(1569720.0, r.profit, 0.5);
        assertEquals(TripEngine.PROFIT, r.verdict);
    }

    @Test
    public void lossTrip() {
        TripEngine.Result r = TripEngine.compute(simple(500000, 100));
        assertEquals(-110000.0, r.profit, 0.5);
        assertEquals(TripEngine.LOSS, r.verdict);
    }

    @Test
    public void invalidInputsGiveInsufficient() {
        assertEquals(TripEngine.INSUFFICIENT, TripEngine.compute(simple(0, 100)).verdict);
        assertEquals(TripEngine.INSUFFICIENT, TripEngine.compute(simple(1000000, 0)).verdict);
        assertEquals(TripEngine.INSUFFICIENT, TripEngine.compute(simple(Double.NaN, 100)).verdict);
        assertEquals(TripEngine.INSUFFICIENT, TripEngine.compute(simple(-5, 100)).verdict);
        TripEngine.Params p = simple(1000000, 100);
        p.commPct = 100;
        assertFalse(TripEngine.compute(p).valid);
    }

    @Test
    public void commissionZeroAndHigh() {
        TripEngine.Params p = simple(1000000, 10);
        p.commPct = 0;
        assertEquals(974000.0, TripEngine.compute(p).profit, 0.5);
        p.commPct = 99;
        TripEngine.Result r = TripEngine.compute(p);
        assertEquals(-16000.0, r.profit, 0.5);
        assertEquals(TripEngine.LOSS, r.verdict);
    }

    @Test
    public void fuelConsumptionAndPriceAndDepreciation() {
        TripEngine.Params p = simple(3000000, 100);
        p.cons100 = 8;
        assertEquals(160000.0, TripEngine.compute(p).fuel, 0.5);
        p.cons100 = 12;
        assertEquals(240000.0, TripEngine.compute(p).fuel, 0.5);
        p.fuelPrice = 20000;
        assertEquals(480000.0, TripEngine.compute(p).fuel, 0.5);
        p.depPerKm = 0;
        assertEquals(0.0, TripEngine.compute(p).dep, 1e-9);
        p.depPerKm = 3000;
        assertEquals(600000.0, TripEngine.compute(p).dep, 0.5);
    }

    @Test
    public void returnModes() {
        TripEngine.Params p = simple(1000000, 100);
        p.retFare = 900000;
        p.retMode = TripEngine.RET_NONE;
        TripEngine.Result none = TripEngine.compute(p);
        assertEquals(300000.0, none.profit, 0.5);
        assertEquals(1038000.0, none.profitFullReturn, 0.5);
        p.retMode = TripEngine.RET_CERTAIN;
        assertEquals(1038000.0, TripEngine.compute(p).profit, 0.5);
        p.retMode = TripEngine.RET_PROBABLE;
        p.retProb = 0.5;
        assertEquals(669000.0, TripEngine.compute(p).profit, 0.5);
    }

    @Test
    public void returnDifferentDistanceAndEstimatedFlag() {
        TripEngine.Params p = simple(1000000, 100);
        p.retFare = 900000;
        p.retMode = TripEngine.RET_CERTAIN;
        p.retDist = 50;
        assertEquals(1168000.0, TripEngine.compute(p).profit, 0.5);
        TripEngine.Params q = simple(1000000, 100);
        q.retMode = TripEngine.RET_CERTAIN;
        TripEngine.Result r = TripEngine.compute(q);
        assertTrue(r.returnEstimated);
        assertEquals(1120000.0, r.profit, 0.5);
        assertFalse(TripEngine.compute(simple(1000000, 100)).returnEstimated);
    }

    @Test
    public void noDoubleCounting() {
        TripEngine.Result r = TripEngine.compute(base());
        assertEquals(582.4, r.outKm, 1e-6);
        assertEquals(575.6, r.retKm, 1e-6);
        assertEquals(r.outKm + r.retKm, r.totalKm, 1e-9);
        assertEquals(r.totalKm * 2600.0, r.fuel + r.dep, 0.5);
    }

    @Test
    public void shortCityTripHasNoReturnUnlessChosen() {
        TripEngine.Params p = simple(100000, 10);
        assertEquals(0.0, TripEngine.compute(p).retKm, 1e-9);
        p.retMode = TripEngine.RET_CERTAIN;
        assertEquals(10.0, TripEngine.compute(p).retKm, 1e-9);
    }

    @Test
    public void zeroSpeedDoesNotDivide() {
        TripEngine.Params p = simple(1000000, 100);
        p.speed = 0;
        TripEngine.Result r = TripEngine.compute(p);
        assertTrue(r.valid);
        assertTrue(r.hours < 0);
        assertTrue(Double.isNaN(r.perHour));
    }

    @Test
    public void marginalVerdictAndBreakEven() {
        assertEquals(TripEngine.MARGINAL, TripEngine.compute(simple(32000, 10)).verdict);
        TripEngine.Params p = simple(500000, 100);
        double be = TripEngine.compute(p).breakEvenFare;
        TripEngine.Params q = simple(be, 100);
        assertEquals(0.0, TripEngine.compute(q).profit, 1.0);
    }

    @Test
    public void hugeValuesStayFinite() {
        TripEngine.Result r = TripEngine.compute(simple(1e15, 1e6));
        assertTrue(r.valid);
        assertFalse(Double.isNaN(r.profit) || Double.isInfinite(r.profit));
    }

    @Test
    public void perKmAndPerHour() {
        TripEngine.Result r = TripEngine.compute(base());
        assertEquals(1569720.0 / 1158.0, r.perKm, 1e-6);
        assertEquals(1569720.0 / (1158.0 / 65.0), r.perHour, 1e-3);
    }
}
