package com.maximcalc.app;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

public class BubbleControl {
    static volatile boolean on = false;

    static boolean toggle(Context c, boolean prompt) {
        if (on) {
            c.stopService(new Intent(c, FloatingService.class));
            on = false;
            save(c, false);
            return false;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) {
            Toast.makeText(c, "اجازهٔ «نمایش روی برنامه‌های دیگر» را روشن کنید و دوباره بزنید", Toast.LENGTH_LONG).show();
            if (prompt) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            }
            return false;
        }
        start(c);
        on = true;
        save(c, true);
        return true;
    }

    static void start(Context c) {
        Intent s = new Intent(c, FloatingService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            c.startForegroundService(s);
        } else {
            c.startService(s);
        }
    }

    static void save(Context c, boolean v) {
        c.getSharedPreferences("mx", 0).edit().putBoolean("bubble", v).apply();
    }
}
