package com.maximcalc.app;

/** اطلاعات سازنده و برنامه؛ تنها محل نگهداری اطلاعات تماس. */
final class AppInfo {
    static final String APP = "میصرفه؟";
    static final String NAME = "فرشید نبی‌پور";
    static final String EMAIL = "farshid.nabipour78@gmail.com";
    static final String TELEGRAM = "https://t.me/Farshid_Np";
    /** دامنهٔ Hosting پیش‌فرض پروژهٔ Firebase (باید با AndroidManifest یکی باشد). */
    static final String HOSTING_HOST = "maxim-calc.firebaseapp.com";

    private AppInfo() {
    }

    private static String q(String v) {
        return "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    static String contactJson() {
        return "{\"name\":" + q(NAME) + ",\"email\":" + q(EMAIL) + ",\"telegram\":" + q(TELEGRAM) + "}";
    }
}
