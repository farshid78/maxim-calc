package com.maximcalc.app;

import android.annotation.TargetApi;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

@TargetApi(24)
public class BubbleTileService extends TileService {
    @Override
    public void onStartListening() {
        update();
    }

    @Override
    public void onClick() {
        BubbleControl.toggle(this, false);
        update();
    }

    private void update() {
        Tile t = getQsTile();
        if (t == null) {
            return;
        }
        t.setState(BubbleControl.on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel("ماشین‌حساب شناور");
        t.updateTile();
    }
}
