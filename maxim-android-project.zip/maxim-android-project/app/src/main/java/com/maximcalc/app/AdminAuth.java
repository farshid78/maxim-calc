package com.maximcalc.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.ActionCodeSettings;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;

import org.json.JSONObject;

/**
 * ورود مدیر با لینک ایمیلی Firebase. وضعیت «مدیر» فقط در حافظهٔ فرایند نگه داشته می‌شود
 * و بعد از ورود موفق (یا بررسی آنلاین) تنظیم می‌شود؛ هیچ پرچم محلی قابل‌ویرایشی مجوز نمی‌دهد.
 * توکن و لینک هرگز لاگ نمی‌شوند.
 */
final class AdminAuth {
    interface Cb {
        void done(String json);
    }

    static volatile boolean sessionAdmin = false;

    private AdminAuth() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("mx_admin", Context.MODE_PRIVATE);
    }

    private static FirebaseAuth auth() {
        try {
            return FirebaseAuth.getInstance();
        } catch (Exception e) {
            return null;
        }
    }

    static String state(Context c, String msg) {
        JSONObject o = new JSONObject();
        try {
            FirebaseAuth a = auth();
            FirebaseUser u = a == null ? null : a.getCurrentUser();
            boolean mine = u != null && AdminPolicy.isAdminEmail(u.getEmail());
            o.put("signedIn", mine);
            o.put("admin", sessionAdmin && mine);
            o.put("pending", !sp(c).getString("pending", "").isEmpty());
            o.put("email", mine ? AdminPolicy.mask(u.getEmail()) : "");
            o.put("msg", msg == null ? "" : msg);
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    static String errMsg(Exception e) {
        if (e instanceof FirebaseNetworkException) {
            return "اتصال اینترنت برقرار نیست.";
        }
        if (e instanceof FirebaseTooManyRequestsException) {
            return "تعداد درخواست‌ها زیاد است؛ بعداً تلاش کنید.";
        }
        if (e instanceof FirebaseAuthException) {
            String code = ((FirebaseAuthException) e).getErrorCode();
            if ("ERROR_INVALID_ACTION_CODE".equals(code)) {
                return "لینک نامعتبر است یا قبلاً استفاده شده.";
            }
            if ("ERROR_EXPIRED_ACTION_CODE".equals(code)) {
                return "لینک منقضی شده؛ لینک جدید بفرستید.";
            }
            if ("ERROR_OPERATION_NOT_ALLOWED".equals(code)) {
                return "ورود با لینک ایمیل در Firebase فعال نیست (کنسول را بررسی کنید).";
            }
            return "خطای احراز هویت (" + code + ").";
        }
        return "خطای نامشخص در احراز هویت.";
    }

    /** پیام خطای فوری یا رشتهٔ خالی اگر درخواست شروع شد؛ نتیجهٔ نهایی از راه cb می‌آید. */
    static String sendLink(final Context c, String raw, final Cb cb) {
        final String email = AdminPolicy.normalize(raw);
        if (!AdminPolicy.validFormat(email)) {
            return "ایمیل نامعتبر است.";
        }
        if (!AdminPolicy.isAdminEmail(email)) {
            return "این ایمیل برای ورود مدیر مجاز نیست.";
        }
        final FirebaseAuth a = auth();
        if (a == null) {
            return "Firebase روی این نسخه پیکربندی نشده است.";
        }
        final SharedPreferences p = sp(c);
        long now = System.currentTimeMillis();
        String rl = AdminPolicy.checkRate(AdminPolicy.parse(p.getString("sends", "")), now);
        if (!rl.isEmpty()) {
            return rl;
        }
        p.edit().putString("sends", AdminPolicy.record(p.getString("sends", ""), now)).apply();
        ActionCodeSettings s = ActionCodeSettings.newBuilder()
                .setUrl("https://" + AppInfo.HOSTING_HOST + "/")
                .setHandleCodeInApp(true)
                .setAndroidPackageName(c.getPackageName(), false, null)
                .build();
        a.sendSignInLinkToEmail(email, s).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(Task<Void> t) {
                if (t.isSuccessful()) {
                    p.edit().putString("pending", email).apply();
                    cb.done(state(c, "لینک ورود ارسال شد. ایمیل (و پوشهٔ اسپم) را بررسی کنید و لینک را از همین گوشی باز کنید."));
                } else {
                    cb.done(state(c, errMsg(t.getException())));
                }
            }
        });
        return "";
    }

    /** اگر intent شامل لینک ورود Firebase باشد، ورود را کامل می‌کند. */
    static void handle(final Context c, Intent intent, final Cb cb) {
        if (intent == null || intent.getData() == null) {
            return;
        }
        final String link = intent.getData().toString();
        final FirebaseAuth a = auth();
        if (a == null || !a.isSignInWithEmailLink(link)) {
            return;
        }
        final SharedPreferences p = sp(c);
        final String email = p.getString("pending", "");
        if (email.isEmpty()) {
            cb.done(state(c, "ایمیل درخواست‌دهنده روی این دستگاه ثبت نشده؛ دوباره لینک بفرستید و از همین گوشی باز کنید."));
            return;
        }
        a.signInWithEmailLink(email, link).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(Task<AuthResult> t) {
                if (!t.isSuccessful()) {
                    cb.done(state(c, errMsg(t.getException())));
                    return;
                }
                FirebaseUser u = t.getResult().getUser();
                if (u != null && AdminPolicy.isAdminEmail(u.getEmail()) && u.isEmailVerified()) {
                    sessionAdmin = true;
                    p.edit().remove("pending").apply();
                    cb.done(state(c, "ورود مدیر با موفقیت انجام شد."));
                } else {
                    a.signOut();
                    sessionAdmin = false;
                    cb.done(state(c, "این حساب مجاز نیست؛ خارج شدید."));
                }
            }
        });
    }

    /** بررسی آنلاین: بدون اینترنت یا با توکن نامعتبر، دسترسی مدیر داده نمی‌شود. */
    static void verify(final Context c, final Cb cb) {
        final FirebaseAuth a = auth();
        FirebaseUser u = a == null ? null : a.getCurrentUser();
        if (u == null || !AdminPolicy.isAdminEmail(u.getEmail())) {
            sessionAdmin = false;
            cb.done(state(c, "وارد نشده‌اید."));
            return;
        }
        u.getIdToken(true).addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
            @Override
            public void onComplete(Task<GetTokenResult> t) {
                FirebaseUser cu = a.getCurrentUser();
                boolean ok = t.isSuccessful() && cu != null && AdminPolicy.isAdminEmail(cu.getEmail()) && cu.isEmailVerified();
                sessionAdmin = ok;
                cb.done(state(c, ok ? "ورود مدیر تأیید شد." : errMsg(t.getException())));
            }
        });
    }

    static void signOut(Context c) {
        FirebaseAuth a = auth();
        if (a != null) {
            a.signOut();
        }
        sessionAdmin = false;
        sp(c).edit().remove("pending").apply();
    }
}
