package com.maximcalc.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            return;
        }
        if (!c.getSharedPreferences("mx", 0).getBoolean("bubble", false)) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(c)) {
            return;
        }
        try {
            BubbleControl.start(c);
            BubbleControl.on = true;
        } catch (Exception ignored) {
        }
    }
}
