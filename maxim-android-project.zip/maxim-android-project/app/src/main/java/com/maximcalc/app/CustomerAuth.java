package com.maximcalc.app;

import android.content.Context;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONObject;

/** Ordinary customer accounts. Admin authorization remains separately checked by AdminPolicy. */
final class CustomerAuth {
    interface Cb { void done(String json); }
    private CustomerAuth() {}

    private static FirebaseAuth auth() {
        try { return FirebaseAuth.getInstance(); } catch (Exception e) { return null; }
    }

    static String state(String message) {
        JSONObject o = new JSONObject();
        try {
            FirebaseAuth a = auth();
            FirebaseUser u = a == null ? null : a.getCurrentUser();
            boolean admin = u != null && AdminPolicy.isAdminEmail(u.getEmail());
            o.put("signedIn", u != null && !admin);
            o.put("adminAccount", admin);
            o.put("verified", u != null && u.isEmailVerified());
            o.put("email", u != null && !admin && u.getEmail() != null ? u.getEmail() : "");
            o.put("msg", message == null ? "" : message);
        } catch (Exception ignored) {}
        return o.toString();
    }

    private static String error(Exception e) {
        if (e instanceof FirebaseNetworkException) return "اتصال اینترنت برقرار نیست؛ اتصال را بررسی کنید.";
        if (e instanceof FirebaseTooManyRequestsException) return "تعداد تلاش‌ها زیاد است؛ کمی بعد دوباره امتحان کنید.";
        if (e instanceof FirebaseAuthException) {
            String code = ((FirebaseAuthException)e).getErrorCode();
            if ("ERROR_INVALID_EMAIL".equals(code)) return "ساختار ایمیل درست نیست.";
            if ("ERROR_EMAIL_ALREADY_IN_USE".equals(code)) return "این ایمیل قبلاً ثبت‌نام کرده است؛ وارد شوید.";
            if ("ERROR_WEAK_PASSWORD".equals(code)) return "رمز عبور ضعیف است؛ حداقل ۶ نویسه وارد کنید.";
            if ("ERROR_USER_NOT_FOUND".equals(code) || "ERROR_WRONG_PASSWORD".equals(code) || "ERROR_INVALID_CREDENTIAL".equals(code)) return "ایمیل یا رمز عبور درست نیست.";
            if ("ERROR_OPERATION_NOT_ALLOWED".equals(code)) return "ثبت‌نام با ایمیل و رمز عبور در Firebase فعال نیست.";
            return "خطای حساب کاربری (" + code + ").";
        }
        return "خطای نامشخص؛ دوباره تلاش کنید.";
    }

    static String register(final Context c, String rawEmail, String password, final Cb cb) {
        final String email = AdminPolicy.normalize(rawEmail);
        if (!AdminPolicy.validFormat(email)) return "ایمیل معتبر وارد کنید.";
        if (AdminPolicy.isAdminEmail(email)) return "این ایمیل برای حساب مدیر است؛ از بخش ورود مدیر استفاده کنید.";
        if (password == null || password.length() < 6) return "رمز عبور باید حداقل ۶ نویسه باشد.";
        FirebaseAuth a = auth();
        if (a == null) return "Firebase روی این نسخه پیکربندی نشده است.";
        a.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override public void onComplete(Task<AuthResult> t) {
                if (!t.isSuccessful()) { cb.done(state(error(t.getException()))); return; }
                FirebaseUser u = t.getResult() == null ? null : t.getResult().getUser();
                if (u == null) { cb.done(state("حساب ساخته شد اما اطلاعات آن دریافت نشد؛ دوباره وارد شوید.")); return; }
                u.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override public void onComplete(Task<Void> verifyTask) {
                        cb.done(state(verifyTask.isSuccessful()
                                ? "حساب ساخته شد. برای تأیید ایمیل، صندوق ورودی و پوشهٔ هرزنامه را بررسی کنید."
                                : "حساب ساخته شد، اما ایمیل تأیید ارسال نشد؛ از گزینهٔ ارسال مجدد استفاده کنید."));
                    }
                });
            }
        });
        return "";
    }

    static String login(String rawEmail, String password, final Cb cb) {
        final String email = AdminPolicy.normalize(rawEmail);
        if (!AdminPolicy.validFormat(email)) return "ایمیل معتبر وارد کنید.";
        if (AdminPolicy.isAdminEmail(email)) return "این ایمیل برای حساب مدیر است؛ از بخش ورود مدیر استفاده کنید.";
        if (password == null || password.isEmpty()) return "رمز عبور را وارد کنید.";
        FirebaseAuth a = auth();
        if (a == null) return "Firebase روی این نسخه پیکربندی نشده است.";
        a.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override public void onComplete(Task<AuthResult> t) {
                if (!t.isSuccessful()) { cb.done(state(error(t.getException()))); return; }
                FirebaseUser u = t.getResult() == null ? null : t.getResult().getUser();
                cb.done(state(u != null && u.isEmailVerified()
                        ? "ورود موفق بود."
                        : "ورود انجام شد، اما ایمیل هنوز تأیید نشده است؛ ایمیل تأیید را باز کنید و سپس «بررسی وضعیت» را بزنید."));
            }
        });
        return "";
    }

    static String resendVerification(final Cb cb) {
        FirebaseAuth a = auth();
        FirebaseUser u = a == null ? null : a.getCurrentUser();
        if (u == null || u.getEmail() == null || AdminPolicy.isAdminEmail(u.getEmail())) return "ابتدا وارد حساب کاربری خود شوید.";
        if (u.isEmailVerified()) return "ایمیل شما قبلاً تأیید شده است.";
        u.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override public void onComplete(Task<Void> t) {
                cb.done(state(t.isSuccessful() ? "ایمیل تأیید دوباره ارسال شد." : error(t.getException())));
            }
        });
        return "";
    }

    static String refresh(Cb cb) {
        FirebaseAuth a = auth();
        final FirebaseUser u = a == null ? null : a.getCurrentUser();
        if (u == null || AdminPolicy.isAdminEmail(u.getEmail())) { cb.done(state("وارد حساب کاربری نشده‌اید.")); return ""; }
        u.reload().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override public void onComplete(Task<Void> t) {
                FirebaseUser current = auth() == null ? null : auth().getCurrentUser();
                cb.done(state(!t.isSuccessful() ? error(t.getException()) : (current != null && current.isEmailVerified() ? "ایمیل تأیید شد." : "هنوز تأیید ایمیل ثبت نشده است.")));
            }
        });
        return "";
    }

    static String reset(String rawEmail, final Cb cb) {
        final String email = AdminPolicy.normalize(rawEmail);
        if (!AdminPolicy.validFormat(email)) return "ایمیل معتبر وارد کنید.";
        if (AdminPolicy.isAdminEmail(email)) return "برای حساب مدیر از روند ورود مدیر استفاده کنید.";
        FirebaseAuth a = auth();
        if (a == null) return "Firebase روی این نسخه پیکربندی نشده است.";
        a.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override public void onComplete(Task<Void> t) {
                cb.done(state(t.isSuccessful() ? "اگر این ایمیل حساب داشته باشد، لینک تغییر رمز ارسال می‌شود." : error(t.getException())));
            }
        });
        return "";
    }

    static void signOut() {
        FirebaseAuth a = auth();
        if (a != null) a.signOut();
        AdminAuth.sessionAdmin = false;
    }
}
