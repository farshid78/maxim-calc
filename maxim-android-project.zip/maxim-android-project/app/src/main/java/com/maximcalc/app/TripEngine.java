package com.maximcalc.app;

/**
 * موتور محاسبهٔ سود و زیان سفر. کد خالص جاوا، بدون وابستگی به اندروید، قابل آزمون با JUnit.
 * همهٔ مبالغ به تومان و مسافت‌ها به کیلومتر هستند. مقدارهای پیش‌فرض فقط پیشنهادی‌اند، نه نرخ قطعی.
 */
public final class TripEngine {
    public static final int RET_NONE = 0, RET_PROBABLE = 1, RET_CERTAIN = 2;
    public static final int PROFIT = 0, MARGINAL = 1, LOSS = 2, INSUFFICIENT = 3;

    private TripEngine() {
    }

    public static final class Params {
        public double fare, dist, pick;
        public double retDist = -1;          // منفی یعنی «مثل مسافت رفت»
        public double retFare = 0;           // صفر یعنی «نامشخص»
        public int retMode = RET_NONE;
        public double retProb = 1.0;         // فقط برای حالت احتمالی (۰ تا ۱)
        public double assumedRetPct = 100;   // وقتی کرایه برگشت نامشخص است: درصدی از کرایه رفت
        public double commPct = 18, fuelPrice = 10000, cons100 = 11, depPerKm = 1500;
        public double other = 0, speed = 65, interKm = 40;
        public boolean forceInter = false;
        public double marginalPct = 5;       // سود کمتر از این درصد کرایه = «کم یا مرزی»
    }

    public static final class Result {
        public boolean valid;
        public String reason = "";
        public boolean inter, returnEstimated;
        public double outKm, retKm, totalKm;
        public double gross, commission, afterCommission, fuel, dep, other;
        public double profit;                // سناریوی انتخاب‌شده
        public double profitOut;             // سود خالص مستقل مسیر رفت
        public double profitReturn;          // سود خالص مستقل مسیر برگشت با کرایه فرضی
        public double profitNoReturn;        // سود کل با برگشت خالی
        public double profitFullReturn;      // سود کل با مسافر برگشت
        public double expectedRetRevenue;
        public double hours = -1;            // منفی یعنی نامشخص
        public double perKm, perHour = Double.NaN;
        public double breakEvenFare, breakEvenReturnFare;
        public int verdict = INSUFFICIENT;
    }

    private static boolean bad(double v) {
        return Double.isNaN(v) || Double.isInfinite(v) || v < 0;
    }

    private static Result invalid(String why) {
        Result r = new Result();
        r.valid = false;
        r.reason = why;
        r.verdict = INSUFFICIENT;
        return r;
    }

    /** Minimum return fare needed so the whole passenger round trip reaches a target net profit. */
    public static double returnFareRequired(Params p, double targetProfit) {
        if (p == null || bad(targetProfit) || bad(p.fare) || bad(p.dist) || bad(p.pick)
                || bad(p.commPct) || p.commPct >= 100 || bad(p.fuelPrice) || bad(p.cons100)
                || bad(p.depPerKm) || bad(p.other)) {
            return Double.NaN;
        }
        double keep = 1 - p.commPct / 100.0;
        double perKm = p.cons100 / 100.0 * p.fuelPrice + p.depPerKm;
        double outKm = p.dist + p.pick;
        double backKm = p.retDist >= 0 ? p.retDist : (p.dist + p.pick);
        return Math.max(0, ((outKm + backKm) * perKm + p.other + targetProfit) / keep - p.fare);
    }

    public static Result compute(Params p) {
        if (bad(p.fare) || bad(p.dist) || bad(p.pick) || bad(p.commPct) || bad(p.fuelPrice) || bad(p.cons100)
                || bad(p.depPerKm) || bad(p.other) || Double.isNaN(p.retProb) || Double.isNaN(p.retFare)
                || bad(p.assumedRetPct) || p.assumedRetPct > 300 || p.commPct >= 100) {
            return invalid("ورودی نامعتبر");
        }
        if (p.fare <= 0 || p.dist <= 0) {
            return invalid("کرایه یا مسافت نامشخص است");
        }
        Result r = new Result();
        r.valid = true;
        double k = 1 - p.commPct / 100.0;
        double perKm = p.cons100 / 100.0 * p.fuelPrice + p.depPerKm;
        r.inter = p.forceInter || p.dist >= p.interKm;
        double defRetKm = p.retDist >= 0 ? p.retDist : (p.dist + p.pick); // passenger return mirrors outbound distance
        double emptyRetKm = p.retDist >= 0 ? p.retDist : p.dist; // empty return has no pickup detour
        boolean back = r.inter || p.retMode != RET_NONE;
        r.outKm = p.dist + p.pick;
        r.retKm = back ? (p.retMode != RET_NONE ? defRetKm : emptyRetKm) : 0;
        r.totalKm = r.outKm + r.retKm;

        double retFareUsed = p.retFare > 0 ? p.retFare : p.fare * p.assumedRetPct / 100.0;
        r.profitOut = p.fare * k - (r.outKm * perKm + p.other);
        r.profitReturn = retFareUsed * k - defRetKm * perKm;
        r.returnEstimated = p.retMode != RET_NONE && p.retFare <= 0;
        double prob = Math.max(0, Math.min(1, p.retProb));
        r.expectedRetRevenue = p.retMode == RET_CERTAIN ? retFareUsed : (p.retMode == RET_PROBABLE ? retFareUsed * prob : 0);

        r.gross = p.fare + r.expectedRetRevenue;
        r.commission = r.gross * p.commPct / 100.0;
        r.afterCommission = r.gross - r.commission;
        r.fuel = r.totalKm * p.cons100 / 100.0 * p.fuelPrice;
        r.dep = r.totalKm * p.depPerKm;
        r.other = p.other;
        r.profit = r.afterCommission - r.fuel - r.dep - p.other;

        double kmNoRet = r.outKm + (r.inter ? emptyRetKm : 0);
        r.profitNoReturn = p.fare * k - (kmNoRet * perKm + p.other);
        double kmFull = r.outKm + defRetKm;
        r.profitFullReturn = (p.fare + retFareUsed) * k - (kmFull * perKm + p.other);

        if (p.speed > 0) {
            r.hours = r.totalKm / p.speed;
            r.perHour = r.profit / r.hours;
        }
        r.perKm = r.totalKm > 0 ? r.profit / r.totalKm : 0;
        r.breakEvenFare = Math.max(0, (r.totalKm * perKm + p.other) / k - r.expectedRetRevenue);
        r.breakEvenReturnFare = Math.max(0, (kmFull * perKm + p.other) / k - p.fare);

        if (r.profit <= 0) {
            r.verdict = LOSS;
        } else if (p.marginalPct > 0 && r.profit < r.gross * p.marginalPct / 100.0) {
            r.verdict = MARGINAL;
        } else {
            r.verdict = PROFIT;
        }
        return r;
    }
}
