package com.maximcalc.app;

import java.util.Locale;

/** قوانین خالص (بدون اندروید) برای ایمیل مجاز مدیر و محدودیت تعداد درخواست؛ قابل آزمون. */
final class AdminPolicy {
    static final long MIN_GAP_MS = 60_000L;
    static final long WINDOW_MS = 3_600_000L;
    static final int MAX_PER_WINDOW = 5;

    private AdminPolicy() {
    }

    static String normalize(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }

    static boolean validFormat(String e) {
        return e != null && e.length() >= 5 && e.length() <= 254
                && e.matches("^[a-z0-9._%+\\-]+@[a-z0-9.\\-]+\\.[a-z]{2,}$");
    }

    static boolean isAdminEmail(String e) {
        return normalize(e).equals(AppInfo.EMAIL);
    }

    static String mask(String e) {
        String n = normalize(e);
        int at = n.indexOf('@');
        return at < 1 ? "" : n.charAt(0) + "***" + n.substring(at);
    }

    static long[] parse(String s) {
        if (s == null || s.isEmpty()) {
            return new long[0];
        }
        String[] p = s.split(",");
        long[] out = new long[p.length];
        int n = 0;
        for (String x : p) {
            try {
                long v = Long.parseLong(x.trim());
                out[n++] = v;
            } catch (NumberFormatException ignored) {
            }
        }
        return java.util.Arrays.copyOf(out, n);
    }

    /** پیام خطا یا رشتهٔ خالی اگر ارسال مجاز است. */
    static String checkRate(long[] times, long now) {
        long last = 0;
        int inWindow = 0;
        for (long t : times) {
            if (t > last) {
                last = t;
            }
            if (now - t < WINDOW_MS && now - t >= 0) {
                inWindow++;
            }
        }
        if (last > 0 && now - last < MIN_GAP_MS && now >= last) {
            return "لطفاً حدود یک دقیقه صبر کنید و دوباره تلاش کنید.";
        }
        if (inWindow >= MAX_PER_WINDOW) {
            return "تعداد درخواست‌ها زیاد است؛ بعداً تلاش کنید.";
        }
        return "";
    }

    static String record(String stored, long now) {
        StringBuilder sb = new StringBuilder();
        for (long t : parse(stored)) {
            if (now - t < WINDOW_MS && now - t >= 0) {
                sb.append(t).append(',');
            }
        }
        return sb.append(now).toString();
    }
}
