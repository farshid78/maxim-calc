package com.maximcalc.app;

import android.app.Activity;
import android.webkit.WebResourceRequest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.app.NotificationManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.functions.HttpsCallableResult;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;
    private final AdminAuth.Cb adminCb = new AdminAuth.Cb() {
        @Override
        public void done(final String json) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (web != null) {
                        web.evaluateJavascript("window.onAdminResult&&onAdminResult(" + org.json.JSONObject.quote(json) + ")", null);
                    }
                }
            });
        }
    };
    private final CustomerAuth.Cb customerCb = new CustomerAuth.Cb() {
        @Override
        public void done(final String json) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (web != null) {
                        web.evaluateJavascript("window.onCustomerResult&&onCustomerResult(" + org.json.JSONObject.quote(json) + ")", null);
                    }
                }
            });
        }
    };

    private void quotaCall(final String method, final String requestId) {
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) { quotaResult("{\"ok\":false,\"code\":\"signed_out\",\"message\":\"ابتدا وارد حساب کاربری شوید.\"}"); return; }
        user.getIdToken(true).addOnCompleteListener(new OnCompleteListener<com.google.firebase.auth.GetTokenResult>() {
            @Override public void onComplete(Task<com.google.firebase.auth.GetTokenResult> tokenTask) {
                if (!tokenTask.isSuccessful()) { quotaResult("{\"ok\":false,\"code\":\"token_error\",\"message\":\"برای بررسی سهمیه اتصال اینترنت را بررسی کنید.\"}"); return; }
                Map<String, Object> data = new HashMap<>();
                if (requestId != null && !requestId.isEmpty()) data.put("requestId", requestId);
                FirebaseFunctions.getInstance().getHttpsCallable(method).call(data)
                    .addOnCompleteListener(new OnCompleteListener<HttpsCallableResult>() {
                        @Override public void onComplete(Task<HttpsCallableResult> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                Object result = task.getResult().getData();
                                quotaResult(result instanceof Map ? new JSONObject((Map<?, ?>) result).toString() : "{\"ok\":false}");
                            } else {
                                String msg = task.getException() == null ? "خطا در دریافت سهمیه." : task.getException().getMessage();
                                JSONObject err = new JSONObject();
                                try { err.put("ok", false); err.put("code", "server_error"); err.put("message", msg == null ? "خطا در ارتباط با سرور." : msg); } catch (Exception ignored) {}
                                quotaResult(err.toString());
                            }
                        }
                    });
            }
        });
    }
    private void quotaResult(final String json) {
        runOnUiThread(new Runnable() { @Override public void run() {
            if (web != null) web.evaluateJavascript("window.onQuotaResult&&onQuotaResult(" + JSONObject.quote(json) + ")", null);
        }});
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#141a24"));
        w.setNavigationBarColor(Color.parseColor("#141a24"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#141a24"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        web.addJavascriptInterface(new StoreBridge(this), "MxStore");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public boolean isOn() {
                return BubbleControl.on;
            }

            @JavascriptInterface
            public void toggle() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        BubbleControl.toggle(MainActivity.this, true);
                    }
                });
            }

            @JavascriptInterface
            public void openA11y() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    }
                });
            }

            @JavascriptInterface
            public boolean a11yOn() {
                return ScreenReaderService.instance != null;
            }

            @JavascriptInterface
            public String lastDump() {
                return MainActivity.this.getSharedPreferences("mx", 0).getString("dump", "");
            }

            @JavascriptInterface
            public void captureIn(final int sec) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "به ماکسیم بروید؛ صفحه بعد از چند ثانیه ثبت می‌شود", Toast.LENGTH_LONG).show();
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                ScreenReaderService.run(getApplicationContext());
                            }
                        }, sec * 1000L);
                    }
                });
            }

            @JavascriptInterface
            public void saveSettings(String json) {
                MainActivity.this.getSharedPreferences("mx", 0).edit().putString("settings", json).apply();
            }

            @JavascriptInterface
            public String status() {
                boolean ov = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(MainActivity.this);
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                boolean bat = Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(getPackageName());
                boolean nt = Build.VERSION.SDK_INT < 24
                        || ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled();
                return "{\"overlay\":" + ov + ",\"a11y\":" + (ScreenReaderService.instance != null)
                        + ",\"battery\":" + bat + ",\"notif\":" + nt + "}";
            }

            @JavascriptInterface
            public void open(final String what) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent i;
                        Uri pkg = Uri.parse("package:" + getPackageName());
                        if ("overlay".equals(what)) {
                            i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
                        } else if ("a11y".equals(what)) {
                            i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                        } else if ("battery".equals(what)) {
                            i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                        } else if ("notif".equals(what) && Build.VERSION.SDK_INT >= 26) {
                            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        } else {
                            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
                        }
                        try {
                            startActivity(i);
                        } catch (Exception ignored) {
                        }
                    }
                });
            }

            @JavascriptInterface
            public String voiceInfo() {
                return ScreenReaderService.voiceInfo();
            }

            @JavascriptInterface
            public void testSound() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ScreenReaderService.testSound();
                    }
                });
            }

            @JavascriptInterface
            public void copy(final String text) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("stats", text));
                        Toast.makeText(MainActivity.this, "کپی شد", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @JavascriptInterface
            public String adminState() {
                return AdminAuth.state(MainActivity.this, "");
            }

            @JavascriptInterface
            public String adminSend(String email) {
                if (email == null || email.length() > 254) {
                    return "ایمیل نامعتبر است.";
                }
                return AdminAuth.sendLink(MainActivity.this, email, adminCb);
            }

            @JavascriptInterface
            public void adminVerify() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        AdminAuth.verify(MainActivity.this, adminCb);
                    }
                });
            }

            @JavascriptInterface
            public void adminSignOut() {
                AdminAuth.signOut(MainActivity.this);
            }
            @JavascriptInterface
            public void quotaStatus() { quotaCall("getQuotaStatus", ""); }

            @JavascriptInterface
            public void consumeQuota(String requestId) { quotaCall("consumeFreeCalculation", requestId); }

            @JavascriptInterface
            public String customerState() {
                return CustomerAuth.state("");
            }

            @JavascriptInterface
            public String customerRegister(String email, String password) {
                return CustomerAuth.register(MainActivity.this, email, password, customerCb);
            }

            @JavascriptInterface
            public String customerLogin(String email, String password) {
                return CustomerAuth.login(email, password, customerCb);
            }

            @JavascriptInterface
            public String customerReset(String email) {
                return CustomerAuth.reset(email, customerCb);
            }

            @JavascriptInterface
            public String customerResendVerification() {
                return CustomerAuth.resendVerification(customerCb);
            }

            @JavascriptInterface
            public String customerRefresh() {
                return CustomerAuth.refresh(customerCb);
            }

            @JavascriptInterface
            public void customerSignOut() {
                CustomerAuth.signOut();
            }

            @JavascriptInterface
            public String contact() {
                return AppInfo.contactJson();
            }

            @JavascriptInterface
            public String version() {
                return BuildConfig.VERSION_NAME + (BuildConfig.DEV_TOOLS ? " (Debug)" : "");
            }

            @JavascriptInterface
            public void openUrl(final String url) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent i;
                        if (("mailto:" + AppInfo.EMAIL).equals(url)) {
                            i = new Intent(Intent.ACTION_SENDTO, Uri.parse(url));
                        } else if (AppInfo.TELEGRAM.equals(url)) {
                            i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        } else {
                            Toast.makeText(MainActivity.this, "این پیوند مجاز نیست", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        try {
                            startActivity(i);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "برنامه‌ای برای باز کردن این پیوند پیدا نشد", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }, "Android");
        setContentView(web);
        AdminAuth.handle(this, getIntent(), adminCb);

        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        AdminAuth.handle(this, intent, adminCb);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
