package com.maximcalc.app;

import android.content.Context;
import android.webkit.JavascriptInterface;

public class StoreBridge {
    private final Context c;

    StoreBridge(Context c) {
        this.c = c;
    }

    @JavascriptInterface
    public String get(String k) {
        return c.getSharedPreferences("mx", 0).getString(k, "");
    }

    @JavascriptInterface
    public void set(String k, String v) {
        c.getSharedPreferences("mx", 0).edit().putString(k, v).apply();
    }
}
