package com.maximcalc.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.Configuration;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.view.MotionEvent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

public class ScreenReaderService extends AccessibilityService {
    static volatile ScreenReaderService instance;
    private static final String PKG = "ir.taxsee.driver";

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LinearLayout card;
    private TextView t1, t2, t3, t4, t5;
    private GradientDrawable bg;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String lastKey = "";
    private boolean expanded = false;
    private boolean hasHint = false;
    private String ttsLang = "none";
    private android.media.ToneGenerator tone;
    private boolean lastInter = false;
    private WindowManager.LayoutParams clp;
    private android.widget.CheckBox cb;
    private TextView hq, t6;
    private LinearLayout tickRow;
    private boolean retOn = false, helpOn = false, toggled = false;
    private Trip lastTrip;
    private View tintView;
    private boolean tintShown = false;
    private boolean shown = false;
    private boolean armed = false;
    private int miss = 0;
    private final Runnable tickR = new Runnable() {
        @Override
        public void run() {
            tick();
        }
    };

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildCard();
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    String lang = "none";
                    int r = tts.setLanguage(new Locale("fa", "IR"));
                    if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) {
                        lang = "fa";
                    } else {
                        r = tts.setLanguage(new Locale("fa"));
                        if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) {
                            lang = "fa";
                        } else {
                            r = tts.setLanguage(Locale.US);
                            if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) {
                                lang = "en";
                            }
                        }
                    }
                    ttsLang = lang;
                    ttsReady = !"none".equals(lang);
                }
            }
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence p = event.getPackageName();
        if (p != null && PKG.contentEquals(p)) {
            arm();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        h.removeCallbacks(tickR);
        hide();
        if (tone != null) {
            tone.release();
            tone = null;
        }
        if (tts != null) {
            tts.shutdown();
            tts = null;
            ttsReady = false;
        }
        return super.onUnbind(intent);
    }

    // ---------- تحلیل خودکار ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildCard() {
        tintView = new View(this);
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(0xCC141a24);
        bg.setStroke(dp(3), Color.parseColor("#3fc79a"));
        card.setBackground(bg);
        t1 = line(22, true, "#3fc79a");
        t2 = line(15, true, "#e8edf3");
        t3 = line(15, true, "#e8edf3");
        t4 = line(13, false, "#f0b24a");
        t5 = line(12, false, "#93a1b5");
        card.addView(t1);
        card.addView(t2);
        cb = new android.widget.CheckBox(this);
        cb.setText("مسافر برگشت دارم");
        cb.setTextSize(14);
        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retOn = cb.isChecked();
                toggled = true;
                if (lastTrip != null) {
                    show(lastTrip);
                }
            }
        });
        hq = line(15, true, "#4fb3d9");
        hq.setText("؟");
        hq.setPadding(dp(14), dp(2), dp(14), dp(2));
        hq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helpOn = !helpOn;
                applyVis();
            }
        });
        tickRow = new LinearLayout(this);
        tickRow.setGravity(Gravity.CENTER);
        tickRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tickRow.addView(cb);
        tickRow.addView(hq);
        t6 = line(12, false, "#93a1b5");
        card.addView(t3);
        card.addView(tickRow);
        card.addView(t4);
        card.addView(t6);
        card.addView(t5);
        card.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (clp == null) {
                    return false;
                }
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = clp.x;
                        sy = clp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - tx);
                        int dy = (int) (e.getRawY() - ty);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                        }
                        if (moved) {
                            clp.x = sx + dx;
                            clp.y = sy + dy;
                            wm.updateViewLayout(card, clp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            getSharedPreferences("mx", 0).edit().putInt("cx", clp.x).putInt("cy", clp.y).apply();
                        } else {
                            expanded = !expanded;
                            applyVis();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private TextView line(int size, boolean bold, String color) {
        TextView t = new TextView(this);
        t.setTextSize(size);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.CENTER);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private void arm() {
        if (armed) {
            return;
        }
        armed = true;
        miss = 0;
        h.post(tickR);
    }

    private void tick() {
        boolean ok = false;
        try {
            ok = update() > 0;
        } catch (Exception ignored) {
        }
        if (ok) {
            miss = 0;
            h.postDelayed(tickR, 700);
        } else {
            miss++;
            if (miss >= 2) {
                hide();
            }
            if (miss < 5) {
                h.postDelayed(tickR, 700);
            } else {
                armed = false;
                miss = 0;
                lastKey = "";
            }
        }
    }

    private static class Trip {
        String tariff = "";
        String lastTitle = null;
        double fare = -1, dist = -1, pick = -1;
        boolean hasReq = false;
        java.util.ArrayList<String> addrs = new java.util.ArrayList<>();
    }

    private int update() {
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws == null) {
            return 0;
        }
        boolean warn = false;
        for (AccessibilityWindowInfo w : ws) {
            AccessibilityNodeInfo r = w.getRoot();
            if (r == null || !PKG.equals(String.valueOf(r.getPackageName()))) {
                continue;
            }
            Trip t = new Trip();
            scan(r, t, new int[]{0});
            if (t.fare > 0 && t.dist > 0) {
                show(t);
                return 1;
            }
            if (t.hasReq) {
                warn = true;
            }
        }
        if (warn) {
            showWarn();
            return 2;
        }
        return 0;
    }

    private void scan(AccessibilityNodeInfo n, Trip t, int[] cnt) {
        if (n == null || cnt[0] > 500) {
            return;
        }
        cnt[0]++;
        String id = n.getViewIdResourceName();
        CharSequence tx = n.getText();
        if (id != null && id.endsWith("/request_order")) {
            t.hasReq = true;
        }
        if (id != null && tx != null) {
            String s = tx.toString();
            if (id.endsWith("/tv_price")) {
                t.fare = num(s);
            } else if (id.endsWith("/tv_main_address")) {
                t.addrs.add(s);
            } else if (id.endsWith("/tv_tariff")) {
                t.tariff = s;
            } else if (id.endsWith("/tv_title")) {
                t.lastTitle = s;
            } else if (id.endsWith("/tv_subtitle") && t.lastTitle != null) {
                if (s.contains("طول مسیر")) {
                    t.dist = num(t.lastTitle);
                } else if (s.contains("فاصله")) {
                    t.pick = num(t.lastTitle);
                }
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            scan(n.getChild(i), t, cnt);
        }
    }

    static double num(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                b.append(c);
            } else if (c >= '۰' && c <= '۹') {
                b.append((char) ('0' + (c - '۰')));
            } else if (c >= '٠' && c <= '٩') {
                b.append((char) ('0' + (c - '٠')));
            } else if (c == '.' || c == '٫') {
                b.append('.');
            }
        }
        try {
            return Double.parseDouble(b.toString());
        } catch (Exception e) {
            return -1;
        }
    }

    private double opt(JSONObject o, String k, double def) {
        double x = num(o.optString(k, ""));
        return x > 0 ? x : def;
    }

    private static String fa(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                b.append((char) ('۰' + (c - '0')));
            } else if (c == ',') {
                b.append('٬');
            } else if (c == '.') {
                b.append('٫');
            } else {
                b.append(c);
            }
        }
        return b.toString();
    }

    private static String m(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1e6) {
            s = String.format(Locale.US, "%.2f", a / 1e6).replaceAll("0+$", "").replaceAll("\\.$", "") + " میلیون";
        } else {
            s = String.format(Locale.US, "%,d", Math.round(a / 1000.0)) + " هزار";
        }
        return fa(s);
    }

    private static String clean(String s) {
        int i = 0;
        while (i < s.length() && !Character.isLetterOrDigit(s.charAt(i))) {
            i++;
        }
        return s.substring(i).trim();
    }

    private static String say(double v) {
        double a = Math.abs(v);
        if (a >= 1e6) {
            return String.format(Locale.US, "%.1f", a / 1e6) + " میلیون تومان";
        }
        return Math.round(a / 1000.0) + " هزار تومان";
    }

    private static String sayEn(double v) {
        double a = Math.abs(v);
        if (a >= 1e6) {
            return String.format(Locale.US, "%.1f", a / 1e6) + " million toman";
        }
        return Math.round(a / 1000.0) + " thousand toman";
    }

    private void applyVis() {
        t2.setVisibility(View.VISIBLE);
        t3.setVisibility(View.VISIBLE);
        tickRow.setVisibility(View.VISIBLE);
        t4.setVisibility(hasHint ? View.VISIBLE : View.GONE);
        t6.setVisibility(helpOn ? View.VISIBLE : View.GONE);
        t5.setVisibility(expanded ? View.VISIBLE : View.GONE);
    }

    private void showWarn() {
        setTint(0);
        int col = Color.parseColor("#f0b24a");
        t1.setText("تحلیل در دسترس نیست");
        t1.setTextColor(col);
        bg.setStroke(dp(2), col);
        t2.setText("ساختار صفحهٔ ماکسیم عوض شده؛ برنامه را به‌روز کنید");
        t2.setVisibility(View.VISIBLE);
        t3.setVisibility(View.GONE);
        tickRow.setVisibility(View.GONE);
        t4.setVisibility(View.GONE);
        t6.setVisibility(View.GONE);
        t5.setVisibility(View.GONE);
        attach();
    }

    private void announce(int state, final String sf, final String se) {
        String mode = "2";
        try {
            mode = new JSONObject(getSharedPreferences("mx", 0).getString("settings", "{}")).optString("snd", "2");
        } catch (Exception ignored) {
        }
        if ("0".equals(mode)) {
            return;
        }
        try {
            if (tone == null) {
                tone = new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100);
            }
            int tt = state == 0 ? android.media.ToneGenerator.TONE_PROP_BEEP2
                    : (state == 1 ? android.media.ToneGenerator.TONE_PROP_BEEP : android.media.ToneGenerator.TONE_SUP_ERROR);
            tone.startTone(tt, 350);
        } catch (Exception ignored) {
        }
        if ("2".equals(mode) && ttsReady && tts != null) {
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (tts != null) {
                        tts.speak("fa".equals(ttsLang) ? sf : se, TextToSpeech.QUEUE_FLUSH, null, "mx");
                    }
                }
            }, 500);
        }
    }

    static String voiceInfo() {
        ScreenReaderService s = instance;
        if (s == null) {
            return "سرویس خواندن صفحه روشن نیست";
        }
        if ("fa".equals(s.ttsLang)) {
            return "صدای فارسی موجود است";
        }
        if ("en".equals(s.ttsLang)) {
            return "صدای فارسی روی گوشی نیست؛ انگلیسی و بوق پخش می‌شود";
        }
        return "موتور گفتار نیست؛ فقط بوق پخش می‌شود";
    }

    static void testSound() {
        ScreenReaderService s = instance;
        if (s != null) {
            s.announce(0, "تست صدا. می‌صرفه", "Sound test. Good trip");
        }
    }

    private void setTint(int color) {
        if (color == 0) {
            if (tintShown) {
                try {
                    wm.removeView(tintView);
                } catch (Exception ignored) {
                }
                tintShown = false;
            }
            return;
        }
        tintView.setBackgroundColor(color);
        if (!tintShown) {
            int type = Build.VERSION.SDK_INT >= 22
                    ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            try {
                wm.addView(tintView, lp);
                tintShown = true;
            } catch (Exception ignored) {
            }
            if (tintShown && shown && clp != null) {
                try {
                    wm.removeView(card);
                    wm.addView(card, clp);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void attach() {
        if (shown) {
            return;
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.min((int) (dm.widthPixels * 0.94f), dp(440));
        int type = Build.VERSION.SDK_INT >= 22
                ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        clp = new WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        clp.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences sp = getSharedPreferences("mx", 0);
        int x = sp.getInt("cx", -1);
        int y = sp.getInt("cy", -1);
        clp.x = x >= 0 ? Math.min(x, Math.max(0, dm.widthPixels - w)) : (dm.widthPixels - w) / 2;
        clp.y = y >= 0 ? Math.min(y, Math.max(0, dm.heightPixels - dp(80))) : (int) (dm.heightPixels * 0.115f);
        try {
            wm.addView(card, clp);
            shown = true;
        } catch (Exception ignored) {
        }
    }

    private void logHist(SharedPreferences sp, String key, Trip t, double net, double netWith, boolean inter, String from, String to, double grossB) {
        try {
            JSONArray a = new JSONArray(sp.getString("hist", "[]"));
            for (int i = Math.max(0, a.length() - 30); i < a.length(); i++) {
                if (key.equals(a.getJSONObject(i).optString("id"))) {
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("id", key);
            o.put("t", System.currentTimeMillis());
            o.put("fare", t.fare);
            o.put("dist", t.dist);
            o.put("net", net);
            o.put("netWith", netWith);
            o.put("grossB", grossB);
            o.put("from", from);
            o.put("to", to);
            o.put("inter", inter);
            o.put("taken", false);
            o.put("ret", false);
            a.put(o);
            while (a.length() > 200) {
                a.remove(0);
            }
            sp.edit().putString("hist", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void updateHist(SharedPreferences sp, String key, boolean ret) {
        try {
            JSONArray a = new JSONArray(sp.getString("hist", "[]"));
            for (int i = a.length() - 1; i >= 0; i--) {
                JSONObject r = a.getJSONObject(i);
                if (key.equals(r.optString("id"))) {
                    r.put("ret", ret);
                    sp.edit().putString("hist", a.toString()).apply();
                    return;
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void show(Trip t) {
        lastTrip = t;
        SharedPreferences sp = getSharedPreferences("mx", 0);
        JSONObject o;
        try {
            o = new JSONObject(sp.getString("settings", "{}"));
        } catch (Exception e) {
            o = new JSONObject();
        }
        double comm = opt(o, "comm", 18), price = opt(o, "price", 10000);
        double cons = opt(o, "cons", 11), dep = opt(o, "dep", 1500);
        double speed = opt(o, "speed", 65), interKm = opt(o, "interKm", 40);
        double minProfit = Math.max(0, opt(o, "minProfit", 200000));
        double rp = o.has("retp") ? num(o.optString("retp", "")) : 100;
        if (rp < 0) {
            rp = 100;
        }
        TripEngine.Params ep = new TripEngine.Params();
        ep.fare = t.fare;
        ep.dist = t.dist;
        ep.pick = Math.max(t.pick, 0);
        ep.commPct = comm;
        ep.fuelPrice = price;
        ep.cons100 = cons;
        ep.depPerKm = dep;
        ep.speed = speed;
        ep.interKm = interKm;
        ep.forceInter = t.tariff.contains("بین");
        ep.assumedRetPct = rp;
        TripEngine.Result er = TripEngine.compute(ep);
        if (!er.valid) {
            showWarn();
            return;
        }
        boolean inter = er.inter;
        double retFare = t.fare * rp / 100.0;
        double totA = er.totalKm;
        double netA = er.profitNoReturn;
        double netB = er.profitFullReturn;
        double needRet = er.breakEvenReturnFare;
        double floor = er.breakEvenFare;
        double hours = er.hours;

        String key = Math.round(t.fare) + "|" + t.dist + "|" + (t.addrs.size() > 1 ? t.addrs.get(1) : "");
        boolean newReq = !key.equals(lastKey);
        if (newReq) {
            retOn = false;
            helpOn = false;
        }
        double netOut = t.fare * (1 - comm / 100.0) - (t.dist + Math.max(t.pick, 0)) * (cons / 100.0 * price + dep);
        double netReturn = retFare * (1 - comm / 100.0) - t.dist * (cons / 100.0 * price + dep);
        int state = retOn ? (netB >= minProfit ? 0 : 2) : (netA >= minProfit ? 0 : (inter && netB >= minProfit ? 1 : 2));
        int col = Color.parseColor(state == 0 ? "#3fc79a" : (state == 1 ? "#f0b24a" : "#ef5b52"));
        double shown_ = retOn ? netB : netA;

        t1.setText(state == 0 ? (retOn ? "✓ می‌صرفه (با مسافر برگشت)" : "✓ می‌صرفه")
                : (state == 1 ? "فقط با مسافر برگشت به حداقل سود می‌رسد" : "✕ به حداقل سود نمی‌رسد"));
        t1.setTextColor(col);
        bg.setStroke(dp(2), col);
        String lA = (inter ? "جمع سود با برگشت خالی: " : "سود همین سفر: ") + (netA > 0 ? "سود " : "ضرر ") + m(netA);
        String lB = "جمع سود رفت‌وبرگشت با مسافر: " + (netB > 0 ? "سود " : "ضرر ") + m(netB);
        t2.setText(retOn ? lB : lA);
        t3.setText(retOn ? "سود جداگانه مسیر برگشت با مسافر: " + (netReturn > 0 ? "سود " : "ضرر ") + m(netReturn) : "سود خالص مسیر رفت: " + (netOut > 0 ? "سود " : "ضرر ") + m(netOut));
        cb.setChecked(retOn);
        StringBuilder hint = new StringBuilder();
        hint.append("حداقل سود تنظیم‌شده: ").append(m(minProfit)).append(" تومان");
        if (state == 1) {
            hint.append("\nکرایه برگشت باید حداقل ").append(m(needRet)).append(" باشد");
        }
        if (hours > 10) {
            if (hint.length() > 0) {
                hint.append("\n");
            }
            hint.append("⚠ حدود ").append(fa(String.format(Locale.US, "%.0f", hours))).append(" ساعت رانندگی؛ خطرناک است");
        }
        hasHint = hint.length() > 0;
        t4.setText(hint.toString());
        t6.setText(fa("با تیک، فرض می‌شود مسافر برگشت با کرایه تخمینی " + Math.round(rp) + "٪ کرایه رفت (حدود " + m(retFare)
                + ") دارید. سود مسیر رفت و برگشت جدا نمایش داده می‌شود. بدون تیک، برگشت خالی حساب می‌شود؛ کرایه واقعی را در صورت اطلاع وارد تنظیمات/ماشین‌حساب کنید."));
        double outFuel = er.outKm * cons / 100.0 * price;
        double outDep = er.outKm * dep;
        double retKmForCosts = inter ? er.retKm : 0;
        double retFuel = retKmForCosts * cons / 100.0 * price;
        double retDep = retKmForCosts * dep;
        String det = "کرایه رفت " + m(t.fare) + " | مسیر رفت " + String.format(Locale.US, "%.1f", er.outKm) + " کم"
                + "\\nسود رفت = کرایه − کمیسیون − هزینه‌های رفت"
                + "\\nهزینه رفت: بنزین " + m(outFuel) + " | استهلاک " + m(outDep) + " | کمیسیون " + m(t.fare * comm / 100.0)
                + (inter ? "\\nهزینه برگشت خالی: بنزین " + m(retFuel) + " | استهلاک " + m(retDep)
                : "\\nاین سفر طبق تنظیمات، برگشت بین‌شهری فرض نشده است")
                + "\\nسود با برگشت خالی: " + m(netA)
                + "\\nسود برگشت با مسافر (کرایه تخمینی " + Math.round(rp) + "٪): " + m(netReturn)
                + "\\nمجموع با مسافر برگشت: " + m(netB)
                + "\\nکف کرایه رفت برای سربه‌سر شدن: " + m(floor)
                + "\\nزمان رانندگی تخمینی: " + String.format(Locale.US, "%.1f", hours) + " ساعت"; 
        t5.setText(fa(det));
        applyVis();

        String th = o.optString("theme", "auto");
        boolean dark = "dark".equals(th) || ("auto".equals(th)
                && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        bg.setColor(dark ? 0xCC141a24 : 0xD9FFFFFF);
        t2.setTextColor(dark ? 0xFFe8edf3 : 0xFF1b2430);
        t3.setTextColor(dark ? 0xFFe8edf3 : 0xFF1b2430);
        t5.setTextColor(dark ? 0xFF93a1b5 : 0xFF5b6778);
        t6.setTextColor(dark ? 0xFF93a1b5 : 0xFF5b6778);
        cb.setTextColor(dark ? 0xFFe8edf3 : 0xFF1b2430);
        String tm = o.optString("tint", "1");
        int tc = 0;
        if (!"0".equals(tm)) {
            if (state == 0) {
                tc = 0x183FC79A;
            } else if ("2".equals(tm)) {
                tc = state == 1 ? 0x18F0B24A : 0x18EF5B52;
            }
        }
        setTint(tc);

        if (newReq) {
            lastKey = key;
            String from = t.addrs.size() > 0 ? clean(t.addrs.get(0)) : "";
            String to = t.addrs.size() > 1 ? clean(t.addrs.get(1)) : "";
            logHist(sp, key, t, netA, netB, inter, from, to, t.fare + retFare);
        }
        if (toggled) {
            updateHist(sp, key, retOn);
        }
        if (newReq || toggled) {
            toggled = false;
            String sf = state == 0 ? "می‌صرفه. سود " + say(shown_) : (state == 1 ? "فقط با مسافر برگشت می‌صرفه" : "نمی‌صرفه");
            String se = state == 0 ? "Worth it. Profit " + sayEn(shown_)
                    : (state == 1 ? "Only worth it with a return passenger" : "Not worth it");
            if (hours > 10) {
                sf += ". هشدار، بیش از ده ساعت رانندگی";
                se += ". Warning, over ten hours of driving";
            }
            announce(state, sf, se);
        }
        attach();
    }

    private void hide() {
        setTint(0);
        if (shown) {
            try {
                wm.removeView(card);
            } catch (Exception ignored) {
            }
            shown = false;
        }
    }

    // ---------- ثبت دستی صفحه برای عیب‌یابی ----------

    static String build() {
        ScreenReaderService s = instance;
        if (s == null) {
            return "ERROR: service not connected\n";
        }
        StringBuilder sb = new StringBuilder();
        int[] st = {0, 0};
        List<AccessibilityWindowInfo> ws = null;
        try {
            ws = s.getWindows();
        } catch (Exception ignored) {
        }
        sb.append("windows: ").append(ws == null ? "null" : String.valueOf(ws.size())).append("\n");
        boolean any = false;
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                AccessibilityNodeInfo r = w.getRoot();
                if (r == null) {
                    sb.append("window type=").append(w.getType()).append(" root=null\n");
                    continue;
                }
                String pkg = String.valueOf(r.getPackageName());
                if (pkg.equals(s.getPackageName())) {
                    continue;
                }
                sb.append("== window type=").append(w.getType()).append(" package=").append(pkg).append("\n");
                walk(r, 0, sb, st);
                any = true;
            }
        }
        if (!any) {
            AccessibilityNodeInfo r = s.getRootInActiveWindow();
            if (r == null) {
                sb.append("active root: null\n");
            } else {
                sb.append("== active package=").append(r.getPackageName()).append("\n");
                walk(r, 0, sb, st);
            }
        }
        sb.append("nodes total=").append(st[0]).append(" with-text=").append(st[1]).append("\n");
        return sb.toString();
    }

    private static void walk(AccessibilityNodeInfo n, int depth, StringBuilder sb, int[] st) {
        if (n == null || st[1] > 600) {
            return;
        }
        st[0]++;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null || d != null) {
            st[1]++;
            String cls = String.valueOf(n.getClassName());
            cls = cls.substring(cls.lastIndexOf('.') + 1);
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            sb.append(depth).append(" | ").append(n.getViewIdResourceName())
                    .append(" | ").append(cls)
                    .append(" | ").append(t)
                    .append(" | ").append(d)
                    .append(" | ").append(r.toShortString()).append("\n");
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            walk(n.getChild(i), depth + 1, sb, st);
        }
    }

    static void run(Context c) {
        String s = build();
        c.getSharedPreferences("mx", 0).edit().putString("dump", s).apply();
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("page", s));
        } catch (Exception ignored) {
        }
        boolean ok = s.contains("with-text=") && !s.contains("with-text=0\n") && !s.startsWith("ERROR");
        Toast.makeText(c, ok ? "صفحه ثبت و کپی شد" : "ثبت شد ولی متنی پیدا نشد", Toast.LENGTH_LONG).show();
        FloatingService.flash(ok);
    }
}
