package com.maximcalc.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.firebase.functions.HttpsCallableResult;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/** Minimal quota-only bridge for the floating WebView. */
public final class QuotaBridge {
    private final Context context;
    private final WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());

    public QuotaBridge(Context context, WebView web) {
        this.context = context.getApplicationContext();
        this.web = web;
    }

    @JavascriptInterface
    public void quotaStatus() {
        call("getQuotaStatus", "");
    }

    @JavascriptInterface
    public void consumeQuota(String requestId) {
        call("consumeFreeCalculation", requestId == null ? "" : requestId);
    }

    private void call(final String method, final String requestId) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            deliver("{\"ok\":false,\"code\":\"signed_out\",\"message\":\"ابتدا وارد حساب کاربری شوید.\"}");
            return;
        }
        user.getIdToken(true).addOnCompleteListener(new OnCompleteListener<com.google.firebase.auth.GetTokenResult>() {
            @Override public void onComplete(Task<com.google.firebase.auth.GetTokenResult> tokenTask) {
                if (!tokenTask.isSuccessful()) {
                    deliver("{\"ok\":false,\"code\":\"token_error\",\"message\":\"برای بررسی سهمیه اتصال اینترنت را بررسی کنید.\"}");
                    return;
                }
                Map<String, Object> data = new HashMap<>();
                if (requestId != null && !requestId.isEmpty()) data.put("requestId", requestId);
                FirebaseFunctions.getInstance().getHttpsCallable(method).call(data)
                    .addOnCompleteListener(new OnCompleteListener<HttpsCallableResult>() {
                        @Override public void onComplete(Task<HttpsCallableResult> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                Object result = task.getResult().getData();
                                deliver(result instanceof Map ? new JSONObject((Map<?, ?>) result).toString() : "{\"ok\":false}");
                            } else {
                                String msg = task.getException() == null ? "خطا در دریافت سهمیه." : task.getException().getMessage();
                                if (msg != null && (msg.toLowerCase(java.util.Locale.ROOT).contains("not found") || msg.toUpperCase(java.util.Locale.ROOT).contains("NOT_FOUND"))) {
                                    msg = "توابع سهمیه در Firebase پیدا نشدند؛ ابتدا Workflow انتشار Firebase را اجرا کنید و سپس دوباره تلاش کنید.";
                                }
                                JSONObject err = new JSONObject();
                                try { err.put("ok", false); err.put("code", "server_error"); err.put("message", msg == null ? "خطا در ارتباط با سرور." : msg); } catch (Exception ignored) { }
                                deliver(err.toString());
                            }
                        }
                    });
            }
        });
    }

    private void deliver(final String json) {
        main.post(new Runnable() {
            @Override public void run() {
                if (web == null) return;
                web.evaluateJavascript("window.onQuotaResult&&onQuotaResult(" + JSONObject.quote(json) + ")", null);
            }
        });
    }
}
