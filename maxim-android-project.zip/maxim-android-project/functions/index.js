const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
initializeApp();
const db = getFirestore();
const FREE_LIMIT = 3;
function requireCustomer(req) {
  if (!req.auth) throw new HttpsError('unauthenticated', 'برای استفاده وارد حساب شوید.');
  if (!req.auth.token.email_verified) throw new HttpsError('failed-precondition', 'ابتدا ایمیل خود را تأیید کنید.');
  const email = String(req.auth.token.email || '').toLowerCase();
  if (!email) throw new HttpsError('failed-precondition', 'ایمیل حساب در دسترس نیست.');
  return { uid: req.auth.uid, email };
}
exports.getQuotaStatus = onCall({ enforceAppCheck: false }, async (req) => {
  const { uid, email } = requireCustomer(req);
  const ref = db.collection('entitlements').doc(uid);
  const snap = await ref.get();
  const data = snap.exists ? snap.data() : {};
  const used = Math.max(0, Number.isInteger(data.freeUsed) ? data.freeUsed : 0);
  const pro = data.pro === true;
  return { ok: true, pro, freeLimit: FREE_LIMIT, freeUsed: Math.min(used, FREE_LIMIT), freeRemaining: pro ? -1 : Math.max(0, FREE_LIMIT - used), email };
});
exports.consumeFreeCalculation = onCall({ enforceAppCheck: false }, async (req) => {
  const { uid } = requireCustomer(req);
  const requestId = String((req.data && req.data.requestId) || '');
  if (!/^[A-Za-z0-9_-]{8,100}$/.test(requestId)) {
    throw new HttpsError('invalid-argument', 'شناسه محاسبه معتبر نیست.');
  }
  const ref = db.collection('entitlements').doc(uid);
  const requestRef = ref.collection('calculationRequests').doc(requestId);
  return db.runTransaction(async (tx) => {
    const [snap, priorRequest] = await Promise.all([tx.get(ref), tx.get(requestRef)]);
    const data = snap.exists ? snap.data() : {};
    if (priorRequest.exists) {
      const used = Math.max(0, Number.isInteger(data.freeUsed) ? data.freeUsed : 0);
      const pro = data.pro === true;
      return { ok: true, pro, freeLimit: FREE_LIMIT, freeUsed: Math.min(used, FREE_LIMIT), freeRemaining: pro ? -1 : Math.max(0, FREE_LIMIT - used), allowed: true, duplicate: true };
    }
    if (data.pro === true) {
      tx.set(requestRef, { createdAt: FieldValue.serverTimestamp(), pro: true });
      return { ok: true, pro: true, freeLimit: FREE_LIMIT, freeUsed: Number(data.freeUsed || 0), freeRemaining: -1, allowed: true };
    }
    const used = Math.max(0, Number.isInteger(data.freeUsed) ? data.freeUsed : 0);
    if (used >= FREE_LIMIT) return { ok: true, pro: false, freeLimit: FREE_LIMIT, freeUsed: FREE_LIMIT, freeRemaining: 0, allowed: false, reason: 'free_limit_reached' };
    const next = used + 1;
    tx.set(ref, { emailVerified: true, freeUsed: next, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    tx.set(requestRef, { createdAt: FieldValue.serverTimestamp(), pro: false });
    return { ok: true, pro: false, freeLimit: FREE_LIMIT, freeUsed: next, freeRemaining: FREE_LIMIT - next, allowed: true };
  });
});
