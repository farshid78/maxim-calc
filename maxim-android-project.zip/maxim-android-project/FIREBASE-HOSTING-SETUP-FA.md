# راه‌اندازی Firebase Hosting و GitHub Actions — پروژهٔ «میصرفه؟»

## شناسهٔ پروژهٔ فعلی

فایل‌های این بسته یعنی `app/google-services.json` و `.firebaserc` هر دو به پروژهٔ Firebase با شناسهٔ `maxim-calc` اشاره می‌کنند. Workflow نیز به همین پروژه Deploy می‌کند تا تنظیمات فعلی برنامه و لینک‌های `maxim-calc.firebaseapp.com` با هم سازگار بمانند.

**مهم:** کلید سرویس‌اکانتی که در چت قبلی فرستاده شد متعلق به پروژهٔ `maxim-calc-512722` است. این شناسه با پروژهٔ مقصد `maxim-calc` متفاوت است. خودِ YAML نمی‌تواند مجوز دسترسی ایجاد کند. برای اجرای Workflow باید یکی از این کارها را انجام دهید:

1. در پروژهٔ مقصد `maxim-calc` یک Service Account برای GitHub Actions بسازید و کلید جدید آن را در GitHub Secret بگذارید؛ یا
2. سرویس‌اکانت موجود را به IAM پروژهٔ مقصد `maxim-calc` اضافه کنید و نقش‌های لازم را به آن بدهید.

اگر پروژهٔ مقصد واقعی شما در Firebase Console در اصل `maxim-calc-512722` است، این بسته را بدون اصلاح تنظیمات استفاده نکنید: ابتدا از همان پروژه یک `google-services.json` تازه برای برنامهٔ Android با package name `com.maximcalc.app` بگیرید؛ بعد شناسهٔ پروژه را در `google-services.json`، `.firebaserc` و Workflow یکسان کنید. شناسهٔ پروژه را فقط با ویرایش دستی JSON تغییر ندهید.

## GitHub Secret

در مخزن GitHub به `Settings → Secrets and variables → Actions` بروید و Repository Secret زیر را بسازید:

- نام: `FIREBASE_SERVICE_ACCOUNT_MAXIM_CALC`
- مقدار: کل محتوای JSON کلید یک Service Account که به پروژهٔ مقصد `maxim-calc` دسترسی دارد.

کلید خصوصی را در کد Workflow، در فایل ZIP یا در مخزن GitHub قرار ندهید. کلیدی که در چت افشا شده باید حذف شود و Secret باید با کلید جدید جایگزین شود.

## نقش‌های IAM پیشنهادی

روی **پروژهٔ مقصد `maxim-calc`**، به ایمیل `client_email` سرویس‌اکانتی که در Secret گذاشته‌اید این نقش‌ها را بدهید:

- `Firebase Hosting Admin` (`roles/firebasehosting.admin`)
- `Service Usage Consumer` (`roles/serviceusage.serviceUsageConsumer`)
- `Service Usage API Keys Viewer` (`roles/serviceusage.apiKeysViewer`)
- `Firebase Viewer` (`roles/firebase.viewer`) برای خواندن اطلاعات پروژه توسط Firebase CLI

در صورت غیرفعال بودن Firebase Hosting API در پروژهٔ مقصد، آن را در Google Cloud Console فعال کنید. به Workflow مرحلهٔ `firebase projects:list` اضافه نشده است؛ برای انتشار به یک پروژهٔ معلوم لازم نیست تمام پروژه‌های حساب فهرست شوند.

## اجرای Workflow

فایل Workflow باید در مخزن GitHub و دقیقاً در مسیر زیر باشد:

`.github/workflows/build-apk.yml`

مخزن باید فایل `maxim-android-project.zip` را در ریشه داشته باشد. با هر push به شاخهٔ `main` یا از مسیر `Actions → Run workflow`، تست‌ها و ساخت APK اجرا می‌شوند و Job جداگانه برای Firebase Hosting تلاش می‌کند.

اگر انتشار Hosting شکست خورد، در گزارش Job دنبال آخرین خطای `firebase deploy --debug` بگردید. خود فایل YAML نمی‌تواند نقش IAM را به حساب اضافه کند.
