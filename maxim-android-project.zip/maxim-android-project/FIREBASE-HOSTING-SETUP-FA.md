راه‌اندازی Firebase Hosting و ورود ایمیلی — پروژهٔ «میصرفه؟»

این پروژه شامل firebase.json، فایل .firebaserc و پوشهٔ hosting است. ورک‌فلو GitHub Actions که همراه بسته ارائه شده، Hosting را در یک Job جداگانه منتشر می‌کند؛ بنابراین اگر انتشار Hosting با خطا مواجه شود، Job ساخت APK همچنان می‌تواند کامل شود.

نیازمندی‌های GitHub:
- یک Repository Secret با نام FIREBASE_SERVICE_ACCOUNT_MAXIM_CALC بسازید.
- مقدار Secret باید محتوای JSON کلید یک Service Account متعلق به پروژه maxim-calc باشد.
- Service Account دست‌کم باید مجوز Firebase Hosting Admin و Service Usage API Keys Viewer داشته باشد.
- کلید سرویس‌اکانت را داخل مخزن، ZIP، یا کد workflow قرار ندهید.

نکته دربارهٔ ورود ایمیلی:
برنامه لینک‌های Hosting را با مسیر /__/auth/links می‌گیرد. در Firebase Console باید برنامهٔ Android، SHA-1/SHA-256 و ورود با Email link درست تنظیم شده باشند. انتشار Hosting صفحهٔ ریشه را فراهم می‌کند؛ به‌تنهایی تضمین نمی‌کند که هر لینک ایمیلی به‌درستی به برنامه هدایت شود. پس از Deploy، حتماً یک لینک تازه از داخل برنامه درخواست و آزمایش کنید.

اجرای محلی (در صورت نیاز): از پوشه‌ای که firebase.json و .firebaserc قرار دارند، با کاربری که به پروژه maxim-calc دسترسی دارد اجرا کنید:
  npm install -g firebase-tools
  firebase login
  firebase use maxim-calc
  firebase deploy --only hosting
