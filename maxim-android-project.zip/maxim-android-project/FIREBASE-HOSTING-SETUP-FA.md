راه‌اندازی Firebase Hosting و ورود ایمیلی — پروژهٔ «میصرفه؟»

شناسهٔ هدف Firebase برای Android و Hosting برابر maxim-calc است. فایل app/google-services.json و فایل .firebaserc باید به همین پروژه اشاره کنند.

نیازمندی‌های GitHub:
- یک Repository Secret با نام FIREBASE_SERVICE_ACCOUNT_MAXIM_CALC بسازید.
- مقدار Secret باید JSON کلید Service Account باشد که به پروژهٔ هدف maxim-calc دسترسی دارد. بهتر است Service Account در خود پروژهٔ maxim-calc ساخته شود.
- در IAM پروژهٔ maxim-calc نقش‌های Firebase Hosting Admin و Service Usage Consumer را به Service Account بدهید.
- اگر Service Account متعلق به پروژهٔ دیگری است، باید آن را صریحاً به IAM پروژهٔ maxim-calc اضافه کنید؛ صرفاً تغییر project_id در workflow دسترسی ایجاد نمی‌کند.
- کلید سرویس‌اکانت را داخل مخزن، ZIP، یا کد workflow قرار ندهید. اگر کلید خصوصی افشا شد، آن را تعویض و کلید قبلی را حذف کنید.

نکته دربارهٔ ورود ایمیلی:
برنامه لینک‌های Hosting را با مسیر /__/auth/links می‌گیرد. در Firebase Console باید برنامهٔ Android، SHA-1/SHA-256 و ورود با Email link درست تنظیم شده باشند. انتشار Hosting صفحهٔ ریشه را فراهم می‌کند؛ به‌تنهایی تضمین نمی‌کند که هر لینک ایمیلی به‌درستی به برنامه هدایت شود. پس از Deploy، حتماً یک لینک تازه از داخل برنامه درخواست و آزمایش کنید.

اجرای محلی (در صورت نیاز): از پوشه‌ای که firebase.json و .firebaserc قرار دارند، با کاربری که به پروژه maxim-calc دسترسی دارد اجرا کنید:
  npm install -g firebase-tools
  firebase login
  firebase use maxim-calc
  firebase deploy --only hosting
