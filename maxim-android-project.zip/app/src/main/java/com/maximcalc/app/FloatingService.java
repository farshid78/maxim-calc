package com.maximcalc.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {
    static FloatingService inst;
    private WindowManager wm;
    private TextView bubble;
    private LinearLayout panel;
    private WebView web;
    private WindowManager.LayoutParams bp;
    private WindowManager.LayoutParams pp;
    private boolean open = false;
    private boolean longFired = false;
    private final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable lr = new Runnable() {
        @Override
        public void run() {
            captureNow();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        BubbleControl.on = true;
        inst = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startAsForeground();
        buildBubble();
        buildPanel();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void startAsForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("bubble", "حباب شناور", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "bubble")
                : new Notification.Builder(this);
        b.setContentTitle("میصرفه؟ فعال است");
        b.setContentText("حباب شناور روشن است");
        b.setSmallIcon(android.R.drawable.ic_menu_compass);
        b.setOngoing(true);
        b.setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    private void buildBubble() {
        bubble = new TextView(this);
        bubble.setText("؟");
        bubble.setTextSize(26);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        bubble.setTextColor(Color.parseColor("#141a24"));
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.parseColor("#3fc79a"));
        g.setStroke(dp(2), Color.parseColor("#141a24"));
        bubble.setBackground(g);

        bp = new WindowManager.LayoutParams(dp(54), dp(54), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.START;
        bp.x = dp(6);
        bp.y = dp(220);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bp.x;
                        sy = bp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        longFired = false;
                        h.postDelayed(lr, 800);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - tx);
                        int dy = (int) (e.getRawY() - ty);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                        }
                        if (moved) {
                            h.removeCallbacks(lr);
                            bp.x = sx + dx;
                            bp.y = sy + dy;
                            wm.updateViewLayout(bubble, bp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        h.removeCallbacks(lr);
                        if (!moved && !longFired) {
                            togglePanel();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(bubble, bp);
    }

    private void buildPanel() {
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#141a24"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#141a24"));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.parseColor("#3fc79a"));
        panel.setBackground(bg);
        panel.setClipToOutline(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(2), dp(4), dp(2));
        TextView title = new TextView(this);
        title.setText("میصرفه؟");
        title.setTextSize(16);
        title.setTextColor(Color.parseColor("#e8edf3"));
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextSize(20);
        close.setTextColor(Color.parseColor("#93a1b5"));
        close.setPadding(dp(14), dp(8), dp(14), dp(8));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closePanel();
            }
        });
        bar.addView(close);
        panel.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        panel.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        pp = new WindowManager.LayoutParams(dp(300), dp(400), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        pp.y = dp(12);
        pp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
    }

    private void captureNow() {
        longFired = true;
        ScreenReaderService.run(this);
    }

    static void flash(boolean ok) {
        FloatingService f = inst;
        if (f != null) {
            f.flashBubble(ok);
        }
    }

    private void flashBubble(boolean ok) {
        if (bubble == null) {
            return;
        }
        bubble.setText(ok ? "✓" : "✕");
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                bubble.setText("؟");
            }
        }, 2500);
    }

    private void togglePanel() {
        if (open) {
            closePanel();
        } else {
            openPanel();
        }
    }

    private void openPanel() {
        if (open) {
            return;
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        pp.width = Math.min((int) (dm.widthPixels * 0.94f), dp(460));
        pp.height = (int) (dm.heightPixels * 0.56f);
        try {
            wm.addView(panel, pp);
            open = true;
            web.requestFocus();
        } catch (Exception ignored) {
        }
    }

    private void closePanel() {
        if (!open) {
            return;
        }
        try {
            wm.removeView(panel);
        } catch (Exception ignored) {
        }
        open = false;
    }

    @Override
    public void onDestroy() {
        closePanel();
        try {
            wm.removeView(bubble);
        } catch (Exception ignored) {
        }
        if (web != null) {
            web.destroy();
        }
        BubbleControl.on = false;
        inst = null;
        super.onDestroy();
    }
}
