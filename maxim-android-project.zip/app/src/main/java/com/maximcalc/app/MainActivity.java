package com.maximcalc.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#141a24"));
        w.setNavigationBarColor(Color.parseColor("#141a24"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#141a24"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new StoreBridge(this), "MxStore");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public boolean isOn() {
                return BubbleControl.on;
            }

            @JavascriptInterface
            public void toggle() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        BubbleControl.toggle(MainActivity.this, true);
                    }
                });
            }

            @JavascriptInterface
            public void openA11y() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    }
                });
            }

            @JavascriptInterface
            public boolean a11yOn() {
                return ScreenReaderService.instance != null;
            }

            @JavascriptInterface
            public String lastDump() {
                return MainActivity.this.getSharedPreferences("mx", 0).getString("dump", "");
            }

            @JavascriptInterface
            public void captureIn(final int sec) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "به ماکسیم بروید؛ صفحه بعد از چند ثانیه ثبت می‌شود", Toast.LENGTH_LONG).show();
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                ScreenReaderService.run(getApplicationContext());
                            }
                        }, sec * 1000L);
                    }
                });
            }

            @JavascriptInterface
            public void saveSettings(String json) {
                MainActivity.this.getSharedPreferences("mx", 0).edit().putString("settings", json).apply();
            }

            @JavascriptInterface
            public String status() {
                boolean ov = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(MainActivity.this);
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                boolean bat = Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(getPackageName());
                boolean nt = Build.VERSION.SDK_INT < 24
                        || ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled();
                return "{\"overlay\":" + ov + ",\"a11y\":" + (ScreenReaderService.instance != null)
                        + ",\"battery\":" + bat + ",\"notif\":" + nt + "}";
            }

            @JavascriptInterface
            public void open(final String what) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent i;
                        Uri pkg = Uri.parse("package:" + getPackageName());
                        if ("overlay".equals(what)) {
                            i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg);
                        } else if ("a11y".equals(what)) {
                            i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                        } else if ("battery".equals(what)) {
                            i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                        } else if ("notif".equals(what) && Build.VERSION.SDK_INT >= 26) {
                            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        } else {
                            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg);
                        }
                        try {
                            startActivity(i);
                        } catch (Exception ignored) {
                        }
                    }
                });
            }
        }, "Android");
        setContentView(web);

        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
