package com.maximcalc.app;

import android.app.Activity;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#141a24"));
        w.setNavigationBarColor(Color.parseColor("#141a24"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#141a24"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public boolean isOn() {
                return BubbleControl.on;
            }

            @JavascriptInterface
            public void toggle() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        BubbleControl.toggle(MainActivity.this, true);
                    }
                });
            }

            @JavascriptInterface
            public void openA11y() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    }
                });
            }
        }, "Android");
        setContentView(web);

        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
