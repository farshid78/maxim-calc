package com.maximcalc.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.List;

public class ScreenReaderService extends AccessibilityService {
    static volatile ScreenReaderService instance;

    @Override
    protected void onServiceConnected() {
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    static String build() {
        ScreenReaderService s = instance;
        if (s == null) {
            return "ERROR: service not connected\n";
        }
        StringBuilder sb = new StringBuilder();
        int[] st = {0, 0};
        List<AccessibilityWindowInfo> ws = null;
        try {
            ws = s.getWindows();
        } catch (Exception ignored) {
        }
        sb.append("windows: ").append(ws == null ? "null" : String.valueOf(ws.size())).append("\n");
        boolean any = false;
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                AccessibilityNodeInfo r = w.getRoot();
                if (r == null) {
                    sb.append("window type=").append(w.getType()).append(" root=null\n");
                    continue;
                }
                String pkg = String.valueOf(r.getPackageName());
                if (pkg.equals(s.getPackageName())) {
                    continue;
                }
                sb.append("== window type=").append(w.getType()).append(" package=").append(pkg).append("\n");
                walk(r, 0, sb, st);
                any = true;
            }
        }
        if (!any) {
            AccessibilityNodeInfo r = s.getRootInActiveWindow();
            if (r == null) {
                sb.append("active root: null\n");
            } else {
                sb.append("== active package=").append(r.getPackageName()).append("\n");
                walk(r, 0, sb, st);
            }
        }
        sb.append("nodes total=").append(st[0]).append(" with-text=").append(st[1]).append("\n");
        return sb.toString();
    }

    private static void walk(AccessibilityNodeInfo n, int depth, StringBuilder sb, int[] st) {
        if (n == null || st[1] > 600) {
            return;
        }
        st[0]++;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null || d != null) {
            st[1]++;
            String cls = String.valueOf(n.getClassName());
            cls = cls.substring(cls.lastIndexOf('.') + 1);
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            sb.append(depth).append(" | ").append(n.getViewIdResourceName())
                    .append(" | ").append(cls)
                    .append(" | ").append(t)
                    .append(" | ").append(d)
                    .append(" | ").append(r.toShortString()).append("\n");
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            walk(n.getChild(i), depth + 1, sb, st);
        }
    }

    static void run(Context c) {
        String s = build();
        c.getSharedPreferences("mx", 0).edit().putString("dump", s).apply();
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("page", s));
        } catch (Exception ignored) {
        }
        boolean ok = s.contains("with-text=") && !s.contains("with-text=0\n") && !s.startsWith("ERROR");
        Toast.makeText(c, ok ? "صفحه ثبت و کپی شد" : "ثبت شد ولی متنی پیدا نشد", Toast.LENGTH_LONG).show();
        FloatingService.flash(ok);
    }
}
