package com.maximcalc.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class ScreenReaderService extends AccessibilityService {
    static volatile ScreenReaderService instance;

    @Override
    protected void onServiceConnected() {
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    static String capture() {
        ScreenReaderService s = instance;
        if (s == null) {
            return null;
        }
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("package: ").append(root.getPackageName()).append("\n");
        walk(root, 0, sb, new int[]{0});
        return sb.toString();
    }

    private static void walk(AccessibilityNodeInfo n, int depth, StringBuilder sb, int[] count) {
        if (n == null || count[0] > 500) {
            return;
        }
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null || d != null) {
            count[0]++;
            String cls = String.valueOf(n.getClassName());
            cls = cls.substring(cls.lastIndexOf('.') + 1);
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            sb.append(depth).append(" | ").append(n.getViewIdResourceName())
                    .append(" | ").append(cls)
                    .append(" | ").append(t)
                    .append(" | ").append(d)
                    .append(" | ").append(r.toShortString()).append("\n");
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            walk(n.getChild(i), depth + 1, sb, count);
        }
    }
}
