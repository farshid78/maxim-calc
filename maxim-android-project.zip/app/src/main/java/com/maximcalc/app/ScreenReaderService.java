package com.maximcalc.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.view.MotionEvent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

public class ScreenReaderService extends AccessibilityService {
    static volatile ScreenReaderService instance;
    private static final String PKG = "ir.taxsee.driver";

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LinearLayout card;
    private TextView t1, t2, t3, t4, t5;
    private GradientDrawable bg;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String lastKey = "";
    private boolean compact = false;
    private boolean lastInter = false;
    private WindowManager.LayoutParams clp;
    private boolean shown = false;
    private boolean armed = false;
    private int miss = 0;
    private final Runnable tickR = new Runnable() {
        @Override
        public void run() {
            tick();
        }
    };

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildCard();
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    int r = tts.setLanguage(new Locale("fa", "IR"));
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                }
            }
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence p = event.getPackageName();
        if (p != null && PKG.contentEquals(p)) {
            arm();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        h.removeCallbacks(tickR);
        hide();
        if (tts != null) {
            tts.shutdown();
            tts = null;
            ttsReady = false;
        }
        return super.onUnbind(intent);
    }

    // ---------- تحلیل خودکار ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildCard() {
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(Color.parseColor("#EE141a24"));
        bg.setStroke(dp(3), Color.parseColor("#3fc79a"));
        card.setBackground(bg);
        t1 = line(22, true, "#3fc79a");
        t2 = line(13, false, "#e8edf3");
        t3 = line(13, false, "#93a1b5");
        t4 = line(13, false, "#93a1b5");
        t5 = line(13, false, "#4fb3d9");
        card.addView(t1);
        card.addView(t2);
        card.addView(t3);
        card.addView(t4);
        card.addView(t5);
        card.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (clp == null) {
                    return false;
                }
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = clp.x;
                        sy = clp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (e.getRawX() - tx);
                        int dy = (int) (e.getRawY() - ty);
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                        }
                        if (moved) {
                            clp.x = sx + dx;
                            clp.y = sy + dy;
                            wm.updateViewLayout(card, clp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            getSharedPreferences("mx", 0).edit().putInt("cx", clp.x).putInt("cy", clp.y).apply();
                        } else {
                            compact = !compact;
                            applyCompact();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private TextView line(int size, boolean bold, String color) {
        TextView t = new TextView(this);
        t.setTextSize(size);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.CENTER);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private void arm() {
        if (armed) {
            return;
        }
        armed = true;
        miss = 0;
        h.post(tickR);
    }

    private void tick() {
        boolean ok = false;
        try {
            ok = update() > 0;
        } catch (Exception ignored) {
        }
        if (ok) {
            miss = 0;
            h.postDelayed(tickR, 700);
        } else {
            miss++;
            if (miss >= 2) {
                hide();
            }
            if (miss < 5) {
                h.postDelayed(tickR, 700);
            } else {
                armed = false;
                miss = 0;
                lastKey = "";
            }
        }
    }

    private static class Trip {
        String tariff = "";
        String lastTitle = null;
        double fare = -1, dist = -1, pick = -1;
        boolean hasReq = false;
        java.util.ArrayList<String> addrs = new java.util.ArrayList<>();
    }

    private int update() {
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws == null) {
            return 0;
        }
        boolean warn = false;
        for (AccessibilityWindowInfo w : ws) {
            AccessibilityNodeInfo r = w.getRoot();
            if (r == null || !PKG.equals(String.valueOf(r.getPackageName()))) {
                continue;
            }
            Trip t = new Trip();
            scan(r, t, new int[]{0});
            if (t.fare > 0 && t.dist > 0) {
                show(t);
                return 1;
            }
            if (t.hasReq) {
                warn = true;
            }
        }
        if (warn) {
            showWarn();
            return 2;
        }
        return 0;
    }

    private void scan(AccessibilityNodeInfo n, Trip t, int[] cnt) {
        if (n == null || cnt[0] > 500) {
            return;
        }
        cnt[0]++;
        String id = n.getViewIdResourceName();
        CharSequence tx = n.getText();
        if (id != null && id.endsWith("/request_order")) {
            t.hasReq = true;
        }
        if (id != null && tx != null) {
            String s = tx.toString();
            if (id.endsWith("/tv_price")) {
                t.fare = num(s);
            } else if (id.endsWith("/tv_main_address")) {
                t.addrs.add(s);
            } else if (id.endsWith("/tv_tariff")) {
                t.tariff = s;
            } else if (id.endsWith("/tv_title")) {
                t.lastTitle = s;
            } else if (id.endsWith("/tv_subtitle") && t.lastTitle != null) {
                if (s.contains("طول مسیر")) {
                    t.dist = num(t.lastTitle);
                } else if (s.contains("فاصله")) {
                    t.pick = num(t.lastTitle);
                }
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            scan(n.getChild(i), t, cnt);
        }
    }

    static double num(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                b.append(c);
            } else if (c >= '۰' && c <= '۹') {
                b.append((char) ('0' + (c - '۰')));
            } else if (c >= '٠' && c <= '٩') {
                b.append((char) ('0' + (c - '٠')));
            } else if (c == '.' || c == '٫') {
                b.append('.');
            }
        }
        try {
            return Double.parseDouble(b.toString());
        } catch (Exception e) {
            return -1;
        }
    }

    private double opt(JSONObject o, String k, double def) {
        double x = num(o.optString(k, ""));
        return x > 0 ? x : def;
    }

    private static String fa(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') {
                b.append((char) ('۰' + (c - '0')));
            } else if (c == ',') {
                b.append('٬');
            } else if (c == '.') {
                b.append('٫');
            } else {
                b.append(c);
            }
        }
        return b.toString();
    }

    private static String m(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1e6) {
            s = String.format(Locale.US, "%.2f", a / 1e6).replaceAll("0+$", "").replaceAll("\\.$", "") + " میلیون";
        } else {
            s = String.format(Locale.US, "%,d", Math.round(a / 1000.0)) + " هزار";
        }
        return fa(s);
    }

    private static String clean(String s) {
        int i = 0;
        while (i < s.length() && !Character.isLetterOrDigit(s.charAt(i))) {
            i++;
        }
        return s.substring(i).trim();
    }

    private static String say(double v) {
        double a = Math.abs(v);
        if (a >= 1e6) {
            return String.format(Locale.US, "%.1f", a / 1e6) + " میلیون تومان";
        }
        return Math.round(a / 1000.0) + " هزار تومان";
    }

    private void applyCompact() {
        int v = compact ? View.GONE : View.VISIBLE;
        t2.setVisibility(v);
        t3.setVisibility(v);
        t4.setVisibility(v);
        t5.setVisibility(!compact && lastInter ? View.VISIBLE : View.GONE);
    }

    private void showWarn() {
        int col = Color.parseColor("#f0b24a");
        t1.setText("تحلیل در دسترس نیست");
        t1.setTextColor(col);
        bg.setStroke(dp(3), col);
        t2.setText("ساختار صفحهٔ ماکسیم عوض شده؛ برنامه را به‌روز کنید");
        t2.setVisibility(View.VISIBLE);
        t3.setVisibility(View.GONE);
        t4.setVisibility(View.GONE);
        t5.setVisibility(View.GONE);
        attach();
    }

    private void attach() {
        if (shown) {
            return;
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.min((int) (dm.widthPixels * 0.94f), dp(440));
        int type = Build.VERSION.SDK_INT >= 22
                ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        clp = new WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        clp.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences sp = getSharedPreferences("mx", 0);
        int x = sp.getInt("cx", -1);
        int y = sp.getInt("cy", -1);
        clp.x = x >= 0 ? Math.min(x, Math.max(0, dm.widthPixels - w)) : (dm.widthPixels - w) / 2;
        clp.y = y >= 0 ? Math.min(y, Math.max(0, dm.heightPixels - dp(80))) : (int) (dm.heightPixels * 0.115f);
        try {
            wm.addView(card, clp);
            shown = true;
        } catch (Exception ignored) {
        }
    }

    private void logHist(SharedPreferences sp, String key, Trip t, double net, double netWith, boolean inter, String from, String to) {
        try {
            JSONArray a = new JSONArray(sp.getString("hist", "[]"));
            for (int i = Math.max(0, a.length() - 30); i < a.length(); i++) {
                if (key.equals(a.getJSONObject(i).optString("id"))) {
                    return;
                }
            }
            JSONObject o = new JSONObject();
            o.put("id", key);
            o.put("t", System.currentTimeMillis());
            o.put("fare", t.fare);
            o.put("dist", t.dist);
            o.put("net", net);
            o.put("netWith", netWith);
            o.put("from", from);
            o.put("to", to);
            o.put("inter", inter);
            o.put("taken", false);
            a.put(o);
            while (a.length() > 200) {
                a.remove(0);
            }
            sp.edit().putString("hist", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void show(Trip t) {
        SharedPreferences sp = getSharedPreferences("mx", 0);
        JSONObject o;
        try {
            o = new JSONObject(sp.getString("settings", "{}"));
        } catch (Exception e) {
            o = new JSONObject();
        }
        double comm = opt(o, "comm", 18), price = opt(o, "price", 10000);
        double cons = opt(o, "cons", 11), dep = opt(o, "dep", 1500);
        boolean inter = t.tariff.contains("بین");
        double pick = Math.max(t.pick, 0);
        double total = t.dist * (inter ? 2 : 1) + pick;
        double fuel = total * cons / 100.0 * price;
        double depr = total * dep;
        double commission = t.fare * comm / 100.0;
        double net = t.fare - commission - fuel - depr;
        double floor = (fuel + depr) / (1 - comm / 100.0);
        double hours = total / 65.0;
        double rp = o.has("retp") ? num(o.optString("retp", "")) : 100;
        if (rp < 0) {
            rp = 100;
        }
        double netWith = net + t.fare * rp / 100.0 * (1 - comm / 100.0);
        double need = Math.max(0, -net / (1 - comm / 100.0));
        boolean win = net > 0;
        int col = Color.parseColor(win ? "#3fc79a" : "#ef5b52");

        t1.setText(win ? "می‌صرفه  •  سود " + m(net) : "نمی‌صرفه  •  ضرر " + m(net));
        t1.setTextColor(col);
        bg.setStroke(dp(3), col);
        t2.setText(fa("کرایه " + m(t.fare).replace("٫", ".") + " | مسیر " + String.format(Locale.US, "%.1f", t.dist) + " کم"
                + (inter ? " × ۲ (برگشت خالی)" : "")));
        t3.setText("بنزین " + m(fuel) + " | استهلاک " + m(depr) + " | کمیسیون " + m(commission));
        t4.setText("حدود " + fa(String.format(Locale.US, "%.1f", hours)) + " ساعت رانندگی | کف کرایه " + m(floor));
        t4.setTextColor(Color.parseColor(hours > 10 ? "#f0b24a" : "#93a1b5"));
        t5.setText("با مسافر برگشت (" + fa(String.valueOf(Math.round(rp))) + "٪ کرایه): "
                + (netWith > 0 ? "سود " : "ضرر ") + m(netWith)
                + (win ? "" : " | کف کرایه برگشت " + m(need)));
        lastInter = inter;
        applyCompact();

        String key = Math.round(t.fare) + "|" + t.dist + "|" + (t.addrs.size() > 1 ? t.addrs.get(1) : "");
        if (!key.equals(lastKey)) {
            lastKey = key;
            String from = t.addrs.size() > 0 ? clean(t.addrs.get(0)) : "";
            String to = t.addrs.size() > 1 ? clean(t.addrs.get(1)) : "";
            logHist(sp, key, t, net, netWith, inter, from, to);
            if (ttsReady && tts != null && !"0".equals(o.optString("voice", "1"))) {
                tts.speak((win ? "می‌صرفه. سود " : "نمی‌صرفه. ضرر ") + say(net)
                        + (hours > 10 ? ". هشدار، بیش از ده ساعت رانندگی" : ""), TextToSpeech.QUEUE_FLUSH, null, "mx");
            }
        }
        attach();
    }

    private void hide() {
        if (shown) {
            try {
                wm.removeView(card);
            } catch (Exception ignored) {
            }
            shown = false;
        }
    }

    // ---------- ثبت دستی صفحه برای عیب‌یابی ----------

    static String build() {
        ScreenReaderService s = instance;
        if (s == null) {
            return "ERROR: service not connected\n";
        }
        StringBuilder sb = new StringBuilder();
        int[] st = {0, 0};
        List<AccessibilityWindowInfo> ws = null;
        try {
            ws = s.getWindows();
        } catch (Exception ignored) {
        }
        sb.append("windows: ").append(ws == null ? "null" : String.valueOf(ws.size())).append("\n");
        boolean any = false;
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                AccessibilityNodeInfo r = w.getRoot();
                if (r == null) {
                    sb.append("window type=").append(w.getType()).append(" root=null\n");
                    continue;
                }
                String pkg = String.valueOf(r.getPackageName());
                if (pkg.equals(s.getPackageName())) {
                    continue;
                }
                sb.append("== window type=").append(w.getType()).append(" package=").append(pkg).append("\n");
                walk(r, 0, sb, st);
                any = true;
            }
        }
        if (!any) {
            AccessibilityNodeInfo r = s.getRootInActiveWindow();
            if (r == null) {
                sb.append("active root: null\n");
            } else {
                sb.append("== active package=").append(r.getPackageName()).append("\n");
                walk(r, 0, sb, st);
            }
        }
        sb.append("nodes total=").append(st[0]).append(" with-text=").append(st[1]).append("\n");
        return sb.toString();
    }

    private static void walk(AccessibilityNodeInfo n, int depth, StringBuilder sb, int[] st) {
        if (n == null || st[1] > 600) {
            return;
        }
        st[0]++;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null || d != null) {
            st[1]++;
            String cls = String.valueOf(n.getClassName());
            cls = cls.substring(cls.lastIndexOf('.') + 1);
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            sb.append(depth).append(" | ").append(n.getViewIdResourceName())
                    .append(" | ").append(cls)
                    .append(" | ").append(t)
                    .append(" | ").append(d)
                    .append(" | ").append(r.toShortString()).append("\n");
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            walk(n.getChild(i), depth + 1, sb, st);
        }
    }

    static void run(Context c) {
        String s = build();
        c.getSharedPreferences("mx", 0).edit().putString("dump", s).apply();
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("page", s));
        } catch (Exception ignored) {
        }
        boolean ok = s.contains("with-text=") && !s.contains("with-text=0\n") && !s.startsWith("ERROR");
        Toast.makeText(c, ok ? "صفحه ثبت و کپی شد" : "ثبت شد ولی متنی پیدا نشد", Toast.LENGTH_LONG).show();
        FloatingService.flash(ok);
    }
}
